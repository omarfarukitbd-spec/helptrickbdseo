<?php
/**
 * SEO Breadcrumbs with Rank Math Fallback
 * Pure semantic HTML5 and Schema.org BreadcrumbList support.
 *
 * @package HelpTrickBD_Pro
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Render Breadcrumbs navigation.
 */
function ht_breadcrumbs() {
    // 1. If Rank Math SEO breadcrumbs function is available and enabled
    if (function_exists('rank_math_the_breadcrumbs')) {
        echo '<div class="ht-breadcrumbs-wrapper">';
        rank_math_the_breadcrumbs();
        echo '</div>';
        return;
    }

    // 2. Native Schema-compliant Breadcrumbs Fallback
    if (is_front_page()) {
        return;
    }

    $sep = ht_m3_icon('arrow_forward', 14, 'ht-crumb-sep', false);
    $home_title = (function_exists('ht_is_bangla_locale') && !ht_is_bangla_locale()) ? esc_html__('Home', 'helptrickbd') : esc_html__('মূল পাতা', 'helptrickbd');
    $aria_label = (function_exists('ht_is_bangla_locale') && !ht_is_bangla_locale()) ? esc_attr__('Breadcrumb Navigation', 'helptrickbd') : esc_attr__('ব্রেডক্রাম্ব নেভিগেশন', 'helptrickbd');

    echo '<nav class="ht-breadcrumbs" aria-label="' . $aria_label . '">';
    echo '<ol itemscope itemtype="https://schema.org/BreadcrumbList">';

    // Home item
    echo '<li itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">';
    echo '<a itemprop="item" href="' . esc_url(home_url('/')) . '">';
    echo ht_m3_icon('home', 14, 'ht-home-icon', false);
    echo '<span itemprop="name">' . esc_html($home_title) . '</span>';
    echo '</a>';
    echo '<meta itemprop="position" content="1" />';
    echo '</li>';

    $position = 2;

    if (is_single()) {
        $cats = get_the_category();
        if (!empty($cats)) {
            $cat = $cats[0];
            $cat_display = function_exists('ht_get_localized_term_name') ? ht_get_localized_term_name($cat) : $cat->name;
            echo '<li class="ht-crumb-sep-item">' . $sep . '</li>';
            echo '<li itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">';
            echo '<a itemprop="item" href="' . esc_url(get_category_link($cat->term_id)) . '">';
            echo '<span itemprop="name">' . esc_html($cat_display) . '</span>';
            echo '</a>';
            echo '<meta itemprop="position" content="' . $position . '" />';
            echo '</li>';
            $position++;
        }

        echo '<li class="ht-crumb-sep-item">' . $sep . '</li>';
        echo '<li itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem" class="ht-crumb-current" aria-current="page">';
        echo '<span itemprop="name">' . esc_html(wp_trim_words(get_the_title(), 8)) . '</span>';
        echo '<meta itemprop="position" content="' . $position . '" />';
        echo '</li>';

    } elseif (is_category()) {
        $queried = get_queried_object();
        $cat_title = ($queried && function_exists('ht_get_localized_term_name')) ? ht_get_localized_term_name($queried) : single_cat_title('', false);
        echo '<li class="ht-crumb-sep-item">' . $sep . '</li>';
        echo '<li itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem" class="ht-crumb-current" aria-current="page">';
        echo '<span itemprop="name">' . esc_html($cat_title) . '</span>';
        echo '<meta itemprop="position" content="' . $position . '" />';
        echo '</li>';

    } elseif (is_tag()) {
        echo '<li class="ht-crumb-sep-item">' . $sep . '</li>';
        echo '<li itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem" class="ht-crumb-current" aria-current="page">';
        echo '<span itemprop="name">' . esc_html(single_tag_title('', false)) . '</span>';
        echo '<meta itemprop="position" content="' . $position . '" />';
        echo '</li>';

    } elseif (is_page()) {
        echo '<li class="ht-crumb-sep-item">' . $sep . '</li>';
        echo '<li itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem" class="ht-crumb-current" aria-current="page">';
        echo '<span itemprop="name">' . esc_html(get_the_title()) . '</span>';
        echo '<meta itemprop="position" content="' . $position . '" />';
        echo '</li>';

    } elseif (is_search()) {
        $search_label = (function_exists('ht_is_bangla_locale') && !ht_is_bangla_locale()) ? esc_html__('Search Results for: ', 'helptrickbd') : esc_html__('অনুসন্ধানের ফলাফল: ', 'helptrickbd');
        echo '<li class="ht-crumb-sep-item">' . $sep . '</li>';
        echo '<li class="ht-crumb-current" aria-current="page">' . $search_label . '"' . esc_html(get_search_query()) . '"</li>';

    } elseif (is_404()) {
        $not_found_label = (function_exists('ht_is_bangla_locale') && !ht_is_bangla_locale()) ? esc_html__('404: Page Not Found', 'helptrickbd') : esc_html__('৪০৪: পৃষ্ঠা পাওয়া যায়নি', 'helptrickbd');
        echo '<li class="ht-crumb-sep-item">' . $sep . '</li>';
        echo '<li class="ht-crumb-current" aria-current="page">' . $not_found_label . '</li>';
    }

    echo '</ol>';
    echo '</nav>';
}


if (!function_exists('htbd_breadcrumbs')) {
    function htbd_breadcrumbs() {
        ht_breadcrumbs();
    }
}
