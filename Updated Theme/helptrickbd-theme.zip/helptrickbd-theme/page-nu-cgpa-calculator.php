<?php
/**
 * Template Name: National University CGPA Calculator
 * Template Post Type: page
 * Description: Dedicated full-canvas interactive web application for NU Honours, Degree & Masters CGPA calculation.
 *
 * @package HelpTrickBD_Pro
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();
?>

<main id="primary" class="ht-main-site ht-cgpa-app-site">
    <div class="ht-container ht-calc-canvas">

        <!-- Breadcrumbs Navigation -->
        <?php
        try {
            if (function_exists('ht_breadcrumbs')) {
                ht_breadcrumbs();
            } elseif (function_exists('htbd_breadcrumbs')) {
                htbd_breadcrumbs();
            }
        } catch (\Throwable $e) {
            // Fail-safe breadcrumbs
        }
        ?>

        <!-- App Hero Card -->
        <header class="ht-app-header-card">
            <h1>জাতীয় বিশ্ববিদ্যালয় সিজিপিএ ক্যালকুলেটর (NU CGPA & SGPA Calculator)</h1>
            <p>স্নাতক (সম্মান) ৪ বছর, ডিগ্রি (পাস) ৩ বছর ও মাস্টার্স ১/২ বছর মেয়াদী কোর্সের সঠিক সিজিপিএ, বিষয়ভিত্তিক জিপিএ, টার্গেট ফার্স্ট ক্লাস প্ল্যানার ও মানোন্নয়ন সিমুলেটর।</p>
        </header>

        <!-- App Control Toolbar -->
        <div class="ht-app-toolbar">
            <div class="ht-app-toolbar-left">
                <span class="ht-app-badge-pro">
                    <svg viewBox="0 0 24 24"><path d="M12 2L9.19 8.63 2 9.24l5.46 4.73L5.82 21 12 17.27 18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2z"/></svg>
                    v2.5 Pro Engine
                </span>
                <span class="ht-app-autosave-status">
                    <span class="ht-autosave-dot"></span>
                    স্বয়ংক্রিয় ড্রাফট সেভ সক্রিয়
                </span>
            </div>
            <div class="ht-app-toolbar-right">
                <button type="button" id="ht-btn-fullscreen" class="ht-tool-btn" title="ফুলস্ক্রিন মোড">
                    <svg viewBox="0 0 24 24"><path d="M7 14H5v5h5v-2H7v-3zm-2-4h2V7h3V5H5v5zm12 7h-3v2h5v-5h-2v3zM14 5v2h3v3h2V5h-5z"/></svg>
                    <span class="ht-btn-text">ফুলস্ক্রিন ভিউ</span>
                </button>
                <button type="button" id="ht-btn-toolbar-print" class="ht-tool-btn" title="গ্রেডশিট প্রিন্ট">
                    <svg viewBox="0 0 24 24"><path d="M19 8H5c-1.66 0-3 1.34-3 3v6h4v4h12v-4h4v-6c0-1.66-1.34-3-3-3zm-3 11H8v-5h8v5zm3-7c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1zm-1-9H6v4h12V3z"/></svg>
                    <span>গ্রেডশিট প্রিন্ট / PDF</span>
                </button>
                <button type="button" id="ht-btn-toolbar-reset" class="ht-tool-btn" title="রিসেট">
                    <svg viewBox="0 0 24 24"><path d="M17.65 6.35C16.2 4.9 14.21 4 12 4c-4.42 0-7.99 3.58-7.99 8s3.57 8 7.99 8c3.73 0 6.84-2.55 7.73-6h-2.08c-.82 2.33-3.04 4-5.65 4-3.31 0-6-2.69-6-6s2.69-6 6-6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35z"/></svg>
                    <span>রিসেট</span>
                </button>
            </div>
        </div>

        <!-- Optional WordPress Post Content Notice -->
        <?php
        try {
            if (have_posts()) :
                while (have_posts()) :
                    the_post();
                    $content = trim(get_the_content());
                    if (!empty($content)) :
            ?>
                <div class="ht-cgpa-admin-banner">
                    <?php the_content(); ?>
                </div>
            <?php
                    endif;
                endwhile;
            endif;
        } catch (\Throwable $e) {
            // Fail-safe post loop
        }
        ?>

        <!-- Interactive Web Application Canvas -->
        <div class="ht-app-core-wrapper">
<div id="htbd-nu-cgpa-app">
<!-- App Header & Program Selector -->
<div class="htbd-app-divider" style="text-align: center; margin-bottom: 25px; border-bottom: 2px solid #f1f5f9; padding-bottom: 20px;">
<span class="htbd-app-badge" style="background: #e0e7ff; color: #3730a3; padding: 5px 14px; border-radius: 20px; font-size: 13.5px; font-weight: 600; display: inline-block; margin-bottom: 10px;">
      NATIONAL UNIVERSITY BANGLADESH • ACADEMIC SUITE
    </span>
<h2 class="htbd-app-title" style="margin: 5px 0 10px 0; color: #0c2340; font-size: 26px; font-weight: 700;">
      জাতীয় বিশ্ববিদ্যালয় সিজিপিএ ক্যালকুলেটর ২০২৬
    </h2>
<p class="htbd-app-subtitle" style="margin: 0; color: #64748b; font-size: 15px;">
      অনার্স, ডিগ্রি পাস ও মাস্টার্স শিক্ষার্থীদের জন্য আধুনিক, সঠিক ও তাৎক্ষণিক রেজাল্ট মূল্যায়ন ব্যবস্থা
    </p>
<!-- Program Selector Pills -->
<div style="display: flex; justify-content: center; gap: 10px; margin-top: 18px; flex-wrap: wrap;">
<button class="htbd-prog-btn active" data-prog="honours" type="button">
        স্নাতক (সম্মান) অনার্স ৪ বছর
      </button>
<button class="htbd-prog-btn" data-prog="degree" type="button">
        ডিগ্রি (পাস) ৩ বছর
      </button>
<button class="htbd-prog-btn" data-prog="masters" type="button">
        মাস্টার্স ১/২ বছর
      </button>
</div>
</div>
<!-- Master Mode Switcher Tabs -->
<div class="htbd-app-divider" style="display: flex; gap: 8px; margin-bottom: 25px; border-bottom: 1px solid #e2e8f0; padding-bottom: 12px; overflow-x: auto;">
<button class="htbd-tab-btn active" data-mode="mode-year" type="button">
      ইয়ার-ওয়াইজ সিজিপিএ
    </button>
<button class="htbd-tab-btn" data-mode="mode-subject" type="button">
      বিষয়ভিত্তিক বিস্তারিত জিপিএ
    </button>
<button class="htbd-tab-btn" data-mode="mode-target" type="button">
      টার্গেট ফার্স্ট ক্লাস প্ল্যানার
    </button>
<button class="htbd-tab-btn" data-mode="mode-improvement" type="button">
      মানোন্নয়ন সিমুলেটর
    </button>
</div>
<!-- Main Grid Layout: Form Area (Left) & Live Dashboard (Right) -->
<div class="htbd-calc-grid">
<!-- LEFT COLUMN: MODE PANELS -->
<div class="htbd-left-panel">
<!-- ================= MODE 1: YEAR-WISE QUICK CGPA ================= -->
<div class="htbd-mode-panel" id="panel-mode-year">
<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">
<h3 style="margin: 0; font-size: 18px; font-weight: 700;">
            বার্ষিক জিপিএ ইনপুট দিন
          </h3>
<span style="font-size: 13px; color: #64748b;">ইনপুট বা স্লাইডার ব্যবহার করুন</span>
</div>
<div id="year-inputs-container" style="display: flex; flex-direction: column; gap: 14px;">
<!-- Year 1 -->
<div class="htbd-year-card" data-year="1">
<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
<span class="htbd-year-title" style="font-weight: 700; color: #1e3a8a; font-size: 15px;">১ম বর্ষ (1st Year)</span>
<div class="htbd-year-credit-lbl" style="font-size: 13px; color: #64748b;">
                ক্রেডিট: <input class="htbd-yr-credit" max="50" min="1" style="width: 52px; padding: 3px 6px; border: 1px solid #cbd5e1; border-radius: 4px; text-align: center;" type="number" value="32"/>
</div>
</div>
<div style="display: flex; align-items: center; gap: 12px;">
<input class="htbd-yr-range" max="4.00" min="0.00" step="0.01" style="flex: 1; accent-color: #2563eb;" type="range" value="0.00"/>
<input class="htbd-yr-gpa" max="4.00" min="0.00" placeholder="0.00" step="0.01" style="width: 75px; padding: 6px 8px; border: 1px solid #94a3b8; border-radius: 6px; font-size: 16px; font-weight: 700; text-align: center;" type="number"/>
</div>
</div>
<!-- Year 2 -->
<div class="htbd-year-card" data-year="2">
<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
<span class="htbd-year-title" style="font-weight: 700; color: #1e3a8a; font-size: 15px;">২য় বর্ষ (2nd Year)</span>
<div class="htbd-year-credit-lbl" style="font-size: 13px; color: #64748b;">
                ক্রেডিট: <input class="htbd-yr-credit" max="50" min="1" style="width: 52px; padding: 3px 6px; border: 1px solid #cbd5e1; border-radius: 4px; text-align: center;" type="number" value="32"/>
</div>
</div>
<div style="display: flex; align-items: center; gap: 12px;">
<input class="htbd-yr-range" max="4.00" min="0.00" step="0.01" style="flex: 1; accent-color: #2563eb;" type="range" value="0.00"/>
<input class="htbd-yr-gpa" max="4.00" min="0.00" placeholder="0.00" step="0.01" style="width: 75px; padding: 6px 8px; border: 1px solid #94a3b8; border-radius: 6px; font-size: 16px; font-weight: 700; text-align: center;" type="number"/>
</div>
</div>
<!-- Year 3 -->
<div class="htbd-year-card" data-year="3">
<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
<span class="htbd-year-title" style="font-weight: 700; color: #1e3a8a; font-size: 15px;">৩য় বর্ষ (3rd Year)</span>
<div class="htbd-year-credit-lbl" style="font-size: 13px; color: #64748b;">
                ক্রেডিট: <input class="htbd-yr-credit" max="50" min="1" style="width: 52px; padding: 3px 6px; border: 1px solid #cbd5e1; border-radius: 4px; text-align: center;" type="number" value="32"/>
</div>
</div>
<div style="display: flex; align-items: center; gap: 12px;">
<input class="htbd-yr-range" max="4.00" min="0.00" step="0.01" style="flex: 1; accent-color: #2563eb;" type="range" value="0.00"/>
<input class="htbd-yr-gpa" max="4.00" min="0.00" placeholder="0.00" step="0.01" style="width: 75px; padding: 6px 8px; border: 1px solid #94a3b8; border-radius: 6px; font-size: 16px; font-weight: 700; text-align: center;" type="number"/>
</div>
</div>
<!-- Year 4 -->
<div class="htbd-year-card" data-year="4">
<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
<span class="htbd-year-title" style="font-weight: 700; color: #1e3a8a; font-size: 15px;">৪র্থ বর্ষ (4th Year)</span>
<div class="htbd-year-credit-lbl" style="font-size: 13px; color: #64748b;">
                ক্রেডিট: <input class="htbd-yr-credit" max="50" min="1" style="width: 52px; padding: 3px 6px; border: 1px solid #cbd5e1; border-radius: 4px; text-align: center;" type="number" value="32"/>
</div>
</div>
<div style="display: flex; align-items: center; gap: 12px;">
<input class="htbd-yr-range" max="4.00" min="0.00" step="0.01" style="flex: 1; accent-color: #2563eb;" type="range" value="0.00"/>
<input class="htbd-yr-gpa" max="4.00" min="0.00" placeholder="0.00" step="0.01" style="width: 75px; padding: 6px 8px; border: 1px solid #94a3b8; border-radius: 6px; font-size: 16px; font-weight: 700; text-align: center;" type="number"/>
</div>
</div>
</div>
<div style="margin-top: 15px; display: flex; gap: 10px;">
<button class="htbd-btn-secondary" id="btn-reset-year" style="flex: 1;" type="button">
            সব মুছে ফেলুন
          </button>
</div>
</div>
<!-- ================= MODE 2: COURSE-WISE DETAILED GPA ================= -->
<div class="htbd-mode-panel" id="panel-mode-subject" style="display: none;">
<div style="margin-bottom: 16px;">
<h3 style="margin: 0 0 6px 0; font-size: 18px; font-weight: 700;">
            বিষয়ভিত্তিক গ্রেড ইনপুট
          </h3>
<p style="margin: 0; font-size: 13.5px; color: #64748b;">
            বিভাগ সিলেক্ট করে সরাসরি সিলেবাস লোড করুন অথবা রেজাল্ট কপি-পেস্ট করুন
          </p>
</div>
<!-- Syllabus Auto-Load Controls -->
<div class="htbd-syllabus-box">
<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-bottom: 10px;">
<div>
<label class="htbd-syllabus-label" style="display: block; font-size: 13px; font-weight: 600; color: #0369a1; margin-bottom: 3px;">বিভাগ (Department)</label>
<select id="sel-dept" style="width: 100%; padding: 6px 8px; border: 1px solid #7dd3fc; border-radius: 6px; font-size: 14px;">
<option value="political_science">রাষ্ট্রবিজ্ঞান (Political Science)</option>
<option value="english">ইংরেজি (English)</option>
<option value="accounting">হিসাববিজ্ঞান (Accounting)</option>
<option value="management">ব্যবস্থাপনা (Management)</option>
<option value="economics">অর্থনীতি (Economics)</option>
<option value="sociology">সমাজবিজ্ঞান (Sociology)</option>
<option value="custom">অন্যান্য / কাস্টম বিষয়</option>
</select>
</div>
<div>
<label class="htbd-syllabus-label" style="display: block; font-size: 13px; font-weight: 600; color: #0369a1; margin-bottom: 3px;">শিক্ষাবর্ষ (Year)</label>
<select id="sel-year" style="width: 100%; padding: 6px 8px; border: 1px solid #7dd3fc; border-radius: 6px; font-size: 14px;">
<option value="1">১ম বর্ষ (1st Year)</option>
<option value="2">২য় বর্ষ (2nd Year)</option>
<option value="3">৩য় বর্ষ (3rd Year)</option>
<option value="4">৪র্থ বর্ষ (4th Year)</option>
</select>
</div>
</div>
<div style="display: flex; gap: 8px;">
<button id="btn-load-syllabus" style="flex: 1; background: #0284c7; color: #ffffff; border: none; padding: 7px 12px; border-radius: 6px; font-size: 13.5px; font-weight: 600; cursor: pointer; transition: 0.2s;" type="button">
              সিলেবাস অটো-লোড
            </button>
<button id="btn-open-smart-paste" style="flex: 1; background: #0f766e; color: #ffffff; border: none; padding: 7px 12px; border-radius: 6px; font-size: 13.5px; font-weight: 600; cursor: pointer; transition: 0.2s;" type="button">
              স্মার্ট পেস্ট পার্সার
            </button>
</div>
</div>
<!-- Smart Paste Modal Box (Hidden by default) -->
<div class="htbd-smart-paste-box" id="smart-paste-box" style="display: none;">
<h4 class="htbd-smart-paste-title" style="margin: 0 0 6px 0; font-size: 14.5px;">রেজাল্ট টেক্সট এখানে পেস্ট করুন:</h4>
<p class="htbd-smart-paste-desc" style="margin: 0 0 8px 0; font-size: 12.5px; color: #64748b;">
            উদাহরণ: <code>221901 - A-, 221903 - B+, 221905 - A</code> অথবা সম্পূর্ণ রেজাল্ট টেবিলের কপি করা লেখা।
          </p>
<textarea id="smart-paste-input" placeholder="Paste result here..." rows="3" style="width: 100%; box-sizing: border-box; padding: 8px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 13px; font-family: monospace;"></textarea>
<div style="display: flex; justify-content: flex-end; gap: 8px; margin-top: 8px;">
<button class="htbd-btn-secondary" id="btn-cancel-paste" style="padding: 6px 12px; font-size: 13px;" type="button">বাতিল</button>
<button id="btn-parse-paste" style="background: #059669; color: #ffffff; border: none; padding: 6px 14px; border-radius: 4px; font-size: 13px; font-weight: 600; cursor: pointer;" type="button">পার্স ও অটো-ফিল</button>
</div>
</div>
<!-- Dynamic Course Table/Container -->
<div class="htbd-course-header">
<div>কোর্স কোড ও নাম</div>
<div style="text-align: center;">ক্রেডিট</div>
<div style="text-align: center;">লেটার গ্রেড</div>
<div style="text-align: center;">পয়েন্ট (GP)</div>
<div style="text-align: center;">মুছুন</div>
</div>
<div id="courses-container" style="display: flex; flex-direction: column; gap: 8px; margin-bottom: 14px;">
<!-- Course Rows injected dynamically via JS -->
</div>
<div style="display: flex; gap: 8px;">
<button id="btn-add-course" style="flex: 1; background: #2563eb; color: #ffffff; border: none; padding: 8px 12px; border-radius: 6px; font-size: 14px; font-weight: 600; cursor: pointer; transition: 0.2s;" type="button">
            + বিষয় যোগ করুন
          </button>
<button class="htbd-btn-secondary" id="btn-reset-courses" style="font-size: 14px;" type="button">
            রিসেট
          </button>
</div>
</div>
<!-- ================= MODE 3: TARGET FIRST CLASS PLANNER ================= -->
<div class="htbd-mode-panel" id="panel-mode-target" style="display: none;">
<h3 style="margin: 0 0 10px 0; font-size: 18px; font-weight: 700;">
          টার্গেট ফার্স্ট ক্লাস (৩.০০) প্ল্যানার
        </h3>
<p style="margin: 0 0 16px 0; font-size: 13.5px; color: #64748b;">
          আপনার বর্তমান সিজিপিএ দিন, টুল হিসাব করে বলে দেবে বাকি বর্ষগুলোতে গড়ে কত জিপিএ লাগবে।
        </p>
<div style="display: flex; flex-direction: column; gap: 14px;">
<div>
<label style="display: block; font-size: 14px; font-weight: 600; margin-bottom: 5px;">
              আপনি কোন বর্ষ পর্যন্ত ফলাফল পেয়েছেন?
            </label>
<select id="target-completed-years" style="width: 100%; padding: 8px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 15px;">
<option value="1">১ম বর্ষের ফলাফল পেয়েছি (বাকি ৩টি বর্ষ)</option>
<option selected="" value="2">২য় বর্ষের ফলাফল পেয়েছি (বাকি ২টি বর্ষ)</option>
<option value="3">৩য় বর্ষের ফলাফল পেয়েছি (বাকি শেষ বর্ষ)</option>
</select>
</div>
<div>
<label style="display: block; font-size: 14px; font-weight: 600; margin-bottom: 5px;">
              আপনার বর্তমান অর্জিত CGPA কত?
            </label>
<input id="target-current-cgpa" max="4.00" min="2.00" step="0.01" style="width: 100%; box-sizing: border-box; padding: 8px 12px; border: 1px solid #94a3b8; border-radius: 6px; font-size: 16px; font-weight: 700;" type="number" value="2.75"/>
</div>
<div>
<label style="display: block; font-size: 14px; font-weight: 600; margin-bottom: 5px;">
              আপনার কাঙ্ক্ষিত টার্গেট কত?
            </label>
<select id="target-goal-cgpa" style="width: 100%; padding: 8px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 15px; font-weight: 600;">
<option selected="" value="3.00">৩.০০ — First Class (১ম শ্রেণি)</option>
<option value="3.25">৩.২৫ — B+ গ্রেড (উচ্চ সম্মান)</option>
<option value="3.50">৩.৫০ — A- গ্রেড (অসাধারণ)</option>
</select>
</div>
<!-- Target Output Card -->
<div class="htbd-target-card" id="target-result-card">
<div class="htbd-target-label" style="font-size: 14px; color: #475569; margin-bottom: 4px;">বাকি বর্ষগুলোতে প্রয়োজনীয় গড় জিপিএ:</div>
<div id="target-req-gpa" style="font-size: 28px; font-weight: 800; color: #2563eb;">3.25</div>
<div class="htbd-badge htbd-target-easy" id="target-badge" style="margin-top: 6px; font-size: 13px; padding: 4px 12px;">
              বাস্তবসম্মত ও অর্জনযোগ্য
            </div>
<p id="target-advice" style="margin: 10px 0 0 0; font-size: 13px; line-height: 1.6; color: #334155;">
              বাকি বর্ষগুলোতে মনোযোগ দিলে অনায়াসেই আপনি ৩.০০ বা ১ম শ্রেণি অর্জন করতে সক্ষম হবেন।
            </p>
</div>
</div>
</div>
<!-- ================= MODE 4: IMPROVEMENT SIMULATOR ================= -->
<div class="htbd-mode-panel" id="panel-mode-improvement" style="display: none;">
<h3 style="margin: 0 0 10px 0; font-size: 18px; font-weight: 700;">
          মানোন্নয়ন (Improvement) সিমুলেটর
        </h3>
<p style="margin: 0 0 16px 0; font-size: 13.5px; color: #64748b;">
          সি বা ডি পাওয়া বিষয়ে মানোন্নয়ন দিলে সিজিপিএ কতটুকু লাফিয়ে বাড়বে তা যাচাই করুন।
        </p>
<div style="display: flex; flex-direction: column; gap: 12px;">
<div>
<label style="display: block; font-size: 13.5px; font-weight: 600; margin-bottom: 4px;">
              বর্তমান বার্ষিক জিপিএ লিখুন:
            </label>
<input id="imp-current-gpa" max="4.00" min="0.00" step="0.01" style="width: 100%; box-sizing: border-box; padding: 8px 12px; border: 1px solid #94a3b8; border-radius: 6px; font-size: 15px; font-weight: 700;" type="number" value="2.65"/>
</div>
<div class="htbd-imp-box">
<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
<span style="font-size: 14px; font-weight: 700; color: #1e3a8a;">মানোন্নয়ন পরীক্ষার বিষয়সমূহ:</span>
<span style="font-size: 12px; color: #64748b;">(সরাসরি পয়েন্ট ইনপুট দিন)</span>
</div>
<!-- Column Header -->
<div class="htbd-imp-header">
<div>কোর্সের নাম</div>
<div style="text-align: center;">পূর্বের পয়েন্ট (GP)</div>
<div style="text-align: center;">টার্গেট পয়েন্ট (GP)*</div>
<div style="text-align: center;">মুছুন</div>
</div>
<div id="imp-courses-list" style="display: flex; flex-direction: column; gap: 8px;">
<!-- Dynamic Improvement Course Rows -->
</div>
<div style="margin-top: 10px; display: flex; gap: 8px;">
<button id="btn-add-imp-course" style="flex: 1; background: #f1f5f9; color: #1e3a8a; border: 1px dashed #93c5fd; padding: 7px 10px; border-radius: 6px; font-size: 13px; font-weight: 600; cursor: pointer; transition: 0.2s;" type="button">
                + আরেকটি বিষয় যোগ করুন
              </button>
</div>
<div style="font-size: 11.5px; color: #64748b; margin-top: 8px; line-height: 1.5;">*এনইউ নিয়ম অনুযায়ী মানোন্নয়নে B+ সর্বোচ্চ সীমা প্রযোজ্য নয় (সংশোধিত রেগুলেশন ২০২৫, ধারা ১৪) — শুধু F গ্রেডের কোর্সে সর্বোচ্চ A-। আপনি সরাসরি আপনার প্রত্যাশিত ফ্র্যাকশনাল বা পূর্ণ গ্রেড পয়েন্ট (যেমন: ৩.২৫, ৩.১০, ২.৮৫ ইত্যাদি) টাইপ করতে পারেন।</div>
</div>
<!-- Improvement Output -->
<div class="htbd-imp-result-box">
<div style="display: flex; justify-content: space-between; align-items: baseline;">
<div>
<span class="htbd-imp-res-label" style="font-size: 13px; color: #065f46; font-weight: 600;">নতুন সম্ভাব্য জিপিএ:</span>
<div id="imp-new-gpa" style="font-size: 26px; font-weight: 800; color: #059669;">2.65</div>
</div>
<div style="text-align: right;">
<span class="htbd-imp-res-label" style="font-size: 12px; color: #065f46; font-weight: 600;">সম্ভাব্য বৃদ্ধি:</span>
<div id="imp-delta-gpa" style="font-size: 18px; font-weight: 700; color: #047857;">+0.00 GPA</div>
</div>
</div>
</div>
</div>
</div>
</div>
<!-- RIGHT COLUMN: UNIFIED LIVE DASHBOARD & ANALYTICS -->
<div class="htbd-right-panel">
<div>
<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
<h3 style="margin: 0; font-size: 18px; font-weight: 700;">ফলাফল ড্যাশবোর্ড</h3>
<span id="dash-program-badge" style="background: #eff6ff; color: #1e40af; padding: 3px 10px; border-radius: 12px; font-size: 12.5px; font-weight: 600;">স্নাতক (সম্মান)</span>
</div>
<!-- Speedometer / Circular Gauge SVG -->
<div style="text-align: center; margin: 10px 0 8px 0;">
<div style="position: relative; width: 135px; height: 135px; margin: 0 auto;">
<svg style="width: 100%; height: 100%; transform: rotate(-90deg);" viewbox="0 0 120 120">
<!-- Background Circle -->
<circle class="dash-gauge-track" cx="60" cy="60" fill="none" r="50" stroke="#f1f5f9" stroke-width="12"></circle>
<!-- Progress Circle -->
<circle cx="60" cy="60" fill="none" id="dash-gauge-circle" r="50" stroke="#2563eb" stroke-dasharray="314.16" stroke-dashoffset="314.16" stroke-linecap="round" stroke-width="12" style="transition: stroke-dashoffset 0.5s ease, stroke 0.3s ease;"></circle>
</svg>
<div style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; display: flex; flex-direction: column; justify-content: center; align-items: center;">
<span id="dash-cgpa-val" style="font-size: 28px; font-weight: 800; color: #0f172a; line-height: 1;">0.00</span>
<span class="dash-gauge-subtext" style="font-size: 11.5px; color: #64748b; font-weight: 600; margin-top: 3px;">আউট অব ৪.০০</span>
</div>
</div>
</div>
<!-- Division & Status Badge -->
<div style="text-align: center; margin-bottom: 16px;">
<div class="htbd-badge htbd-badge-empty" id="dash-division-badge">
            ফলাফল দেখতে ইনপুট দিন
          </div>
</div>
<!-- Metrics Pills -->
<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 20px;">
<div class="htbd-metric-pill">
<div class="htbd-metric-lbl" style="font-size: 12px; color: #64748b;">মোট অর্জিত ক্রেডিট</div>
<div class="htbd-metric-val" id="dash-total-credits" style="font-size: 18px; font-weight: 700; color: #1e293b;">0</div>
</div>
<div class="htbd-metric-pill">
<div class="htbd-metric-lbl" style="font-size: 12px; color: #64748b;">মোট গ্রেড পয়েন্ট</div>
<div class="htbd-metric-val" id="dash-total-points" style="font-size: 18px; font-weight: 700; color: #1e293b;">0.00</div>
</div>
</div>
<!-- Progression Trend Curve (SVG Canvas) -->
<div class="htbd-trend-card">
<div style="font-size: 13px; font-weight: 600; margin-bottom: 8px; display: flex; justify-content: space-between;">
<span class="htbd-trend-title" id="dash-trend-title" style="color: #475569;">বর্ষভিত্তিক অগ্রগতি গ্রাফ</span>
<span id="dash-trend-sub" style="font-size: 11px; color: #94a3b8;">১ম → ৪র্থ বর্ষ</span>
</div>
<div style="height: 60px; width: 100%;">
<svg id="dash-trend-svg" style="width: 100%; height: 100%; overflow: visible;" viewbox="0 0 200 60">
<line class="dash-trend-axis" stroke="#cbd5e1" stroke-width="1" x1="10" x2="190" y1="50" y2="50"></line>
<polyline fill="none" id="dash-trend-line" points="20,50 70,50 120,50 170,50" stroke="#3b82f6" stroke-width="2.5"></polyline>
<g id="dash-trend-points">
<circle cx="20" cy="50" fill="#1e40af" id="p1" r="3.5"></circle>
<circle cx="70" cy="50" fill="#1e40af" id="p2" r="3.5"></circle>
<circle cx="120" cy="50" fill="#1e40af" id="p3" r="3.5"></circle>
<circle cx="170" cy="50" fill="#1e40af" id="p4" r="3.5"></circle>
</g>
</svg>
</div>
</div>
</div>
<!-- Action Buttons -->
<div style="display: flex; flex-direction: column; gap: 8px;">
<button id="btn-print-transcript" style="background: #1e3a8a; color: #ffffff; border: none; padding: 12px; border-radius: 8px; font-size: 15px; font-weight: 700; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 8px; transition: all 0.2s ease; box-shadow: 0 4px 12px rgba(30,58,138,0.2);" type="button">
<svg style="width: 18px; height: 18px; fill: currentColor;" viewbox="0 0 24 24"><path d="M19 8H5c-1.66 0-3 1.34-3 3v6h4v4h12v-4h4v-6c0-1.66-1.34-3-3-3zm-3 11H8v-5h8v5zm3-7c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1zm-1-9H6v4h12V3z"></path></svg> অফিসিয়াল ট্রান্সক্রিপ্ট প্রিন্ট / PDF
        </button>
<button class="htbd-btn-secondary" id="btn-copy-summary" style="padding: 9px; font-size: 14px; text-align: center;" type="button">
          রেজাল্ট সামারি কপি করুন
        </button>
</div>
</div>
</div>
</div>
        </div>

        <!-- Official Grade Certificate & Transcript Modal -->
<div id="htbd-transcript-modal">
<div class="htbd-modal-wrapper">
<!-- Modal Header -->
<div class="htbd-modal-header">
<div style="display: flex; align-items: center; gap: 10px;">
<svg style="width: 24px; height: 24px; fill: #ffffff;" viewbox="0 0 24 24"><path d="M5 13.18v4L12 21l7-3.82v-4L12 17l-7-3.82zM12 3L1 9l11 6 9-4.91V17h2V9L12 3z"></path></svg>
<div>
<h3 style="margin: 0; font-size: 17px; font-weight: 700; color: #ffffff;">জাতীয় বিশ্ববিদ্যালয় প্রাতিষ্ঠানিক ট্রান্সক্রিপ্ট প্রিভিউ</h3>
<div style="font-size: 12px; color: #bfdbfe; margin-top: 2px;">তথ্য কাস্টমাইজ করুন এবং ১-পাতা A4 ট্রান্সক্রিপ্ট প্রিন্ট বা PDF সেভ করুন</div>
</div>
</div>
<button class="btn-modal-close" id="btn-close-modal" title="বন্ধ করুন" type="button"><svg style="width: 14px; height: 14px; fill: currentColor; vertical-align: middle;" viewbox="0 0 24 24"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"></path></svg></button>
</div>
<!-- Live Customizer Toolbar -->
<div class="htbd-modal-toolbar">
<div class="htbd-modal-input-group">
<label class="htbd-modal-label">শিক্ষার্থীর নাম (ঐচ্ছিক):</label>
<input class="htbd-modal-input" id="modal-inp-name" placeholder="আপনার নাম লিখুন..." type="text"/>
</div>
<div class="htbd-modal-input-group">
<label class="htbd-modal-label">কলেজ / শিক্ষাপ্রতিষ্ঠান (ঐচ্ছিক):</label>
<input class="htbd-modal-input" id="modal-inp-college" placeholder="কলেজের নাম লিখুন..." type="text"/>
</div>
<div class="htbd-modal-input-group">
<label class="htbd-modal-label">সেশন / রেজিস্ট্রেশন নং (ঐচ্ছিক):</label>
<input class="htbd-modal-input" id="modal-inp-session" placeholder="যেমন: ২০২০-২১ / ১৮..." type="text"/>
</div>
<div>
<button class="btn-trigger-print" id="btn-trigger-pdf-print" type="button">
<svg style="width: 16px; height: 16px; fill: currentColor; vertical-align: middle; margin-right: 6px;" viewbox="0 0 24 24"><path d="M19 8H5c-1.66 0-3 1.34-3 3v6h4v4h12v-4h4v-6c0-1.66-1.34-3-3-3zm-3 11H8v-5h8v5zm3-7c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1zm-1-9H6v4h12V3z"></path></svg>প্রিন্ট / PDF ডাউনলোড (১ পৃষ্ঠা)
        </button>
</div>
</div>
<!-- Live Preview Sheet Viewport -->
<div class="htbd-preview-scroll">
<!-- ================= THE PURE A4 CERTIFICATE PAPER ================= -->
<div id="htbd-certificate-paper">
<div class="htbd-cert-inner-frame">
<!-- Background Watermark (Ultra-Subtle Unofficial Notice) -->
<div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%) rotate(-25deg); font-size: 38px; font-weight: 800; color: #0c2340; opacity: 0.035; pointer-events: none; z-index: 1; white-space: nowrap; user-select: none; letter-spacing: 4px; text-transform: uppercase;">
            HELPTRICKBD • UNOFFICIAL STUDENT COPY
          </div>
<!-- Document Header -->
<div style="position: relative; z-index: 2; display: flex; align-items: center; justify-content: space-between; border-bottom: 2px solid #1e3a8a; padding-bottom: 12px; margin-bottom: 12px;">
<!-- Left: NU Official Vector Monogram / Emblem -->
<div style="width: 70px; height: 70px; flex-shrink: 0; text-align: center;">
<svg height="70" style="width: 70px !important; height: 70px !important; display: block; margin: 0 auto;" viewbox="0 0 100 100" width="70">
<circle cx="50" cy="50" fill="#1e3a8a" r="47"></circle>
<circle cx="50" cy="50" fill="#ffffff" r="43" stroke="#b45309" stroke-width="1.5"></circle>
<circle cx="50" cy="50" fill="#f8fafc" r="33" stroke="#1e3a8a" stroke-width="1.5"></circle>
<!-- Sunburst -->
<path d="M50 19 L50 25 M38 23 L41 27 M62 23 L59 27 M30 31 L35 33 M70 31 L65 33" stroke="#d97706" stroke-linecap="round" stroke-width="1.8"></path>
<circle cx="50" cy="38" fill="#dc2626" r="11"></circle>
<!-- Open Book -->
<path d="M28 58 Q50 48 50 64 Q50 48 72 58 L72 68 Q50 58 50 74 Q50 58 28 68 Z" fill="#1e3a8a"></path>
<path d="M30 60 Q50 50 50 66 L50 72 Q50 56 30 66 Z" fill="#ffffff" opacity="0.9"></path>
<path d="M70 60 Q50 50 50 66 L50 72 Q50 56 70 66 Z" fill="#ffffff" opacity="0.9"></path>
<line stroke="#b45309" stroke-width="1.5" x1="50" x2="50" y1="50" y2="74"></line>
<!-- Rice Sheaves Base -->
<path d="M28 72 Q50 84 72 72" fill="none" stroke="#15803d" stroke-linecap="round" stroke-width="2.5"></path>
<path d="M24 66 Q26 75 34 80 M76 66 Q74 75 66 80" fill="none" stroke="#15803d" stroke-linecap="round" stroke-width="1.5"></path>
<path d="M36 82 Q50 86 64 82 L60 87 Q50 89 40 87 Z" fill="#b45309"></path>
</svg>
</div>
<!-- Center: University Identification & Document Title -->
<div style="text-align: center; flex: 1; padding: 0 10px;">
<div style="font-size: 18px; font-weight: 800; color: #0c2340; letter-spacing: 0.5px; line-height: 1.2;">জাতীয় বিশ্ববিদ্যালয় গ্রেডিং সিস্টেম</div>
<div style="font-size: 12.5px; font-weight: 700; color: #1e3a8a; letter-spacing: 0.6px; margin-top: 2px;">NATIONAL UNIVERSITY GRADING SYSTEM • BANGLADESH</div>
<div style="font-size: 11px; color: #475569; margin-top: 2px;">হেল্পট্রিকবিডি অনলাইন শিক্ষা প্ল্যাটফর্ম • HelpTrickBD.com EduTools</div>
<div style="display: inline-block; background: #fef2f2; color: #b91c1c; border: 1px solid #fecaca; padding: 3px 14px; border-radius: 4px; font-size: 11px; font-weight: 700; margin-top: 4px; letter-spacing: 0.5px;">
                অনলাইন সিজিপিএ মূল্যায়ন রেকর্ড (শিক্ষার্থী কপি — অফিসিয়াল ট্রান্সক্রিপ্ট নয়)
              </div>
</div>
<!-- Right: Official Document Verification & Serial Box -->
<div style="width: 145px; flex-shrink: 0; text-align: right;">
<div style="border: 1px dashed #f59e0b; border-radius: 4px; padding: 5px 8px; background: #fffbeb; font-size: 9.5px; line-height: 1.35; text-align: left;">
<div style="font-weight: 800; color: #b45309; font-size: 9px; text-transform: uppercase;">UNOFFICIAL REPORT</div>
<div style="font-size: 8.5px; color: #dc2626; font-weight: 700;">মূল সনদ বা ট্রান্সক্রিপ্ট নয়</div>
<div id="cert-ref-no" style="font-family: monospace; font-size: 9px; color: #0f172a; margin-top: 2px;">Ref: HTBD-NU-2026-89412</div>
<div id="cert-issue-date" style="color: #475569; font-size: 9px; margin-top: 1px;">তারিখ: ৩ অক্টোবর, ২০২৬</div>
</div>
</div>
</div>
<!-- Student & Academic Examination Profile Matrix -->
<div style="position: relative; z-index: 2; margin-bottom: 12px;">
<table style="width: 100%; border-collapse: collapse; font-size: 12px; color: #0c2340;">
<tr>
<td style="padding: 4px 8px; border: 1px solid #cbd5e1; background: #f8fafc; width: 17%; font-weight: 700; color: #334155;">শিক্ষার্থীর নাম:</td>
<td style="padding: 4px 8px; border: 1px solid #cbd5e1; width: 33%; font-weight: 700; color: #0c2340;"><span id="cert-student-name">পরীক্ষার্থী (Examinee)</span></td>
<td style="padding: 4px 8px; border: 1px solid #cbd5e1; background: #f8fafc; width: 20%; font-weight: 700; color: #334155;">মোট অর্জিত ক্রেডিট:</td>
<td style="padding: 4px 8px; border: 1px solid #cbd5e1; width: 30%; font-weight: 700; color: #0c2340;"><span id="cert-total-credits">128</span> Credits</td>
</tr>
<tr>
<td style="padding: 4px 8px; border: 1px solid #cbd5e1; background: #f8fafc; font-weight: 700; color: #334155;">কলেজ / প্রতিষ্ঠান:</td>
<td style="padding: 4px 8px; border: 1px solid #cbd5e1; font-weight: 600; color: #0c2340;"><span id="cert-college-name">জাতীয় বিশ্ববিদ্যালয় অধিভুক্ত কলেজ</span></td>
<td style="padding: 4px 8px; border: 1px solid #cbd5e1; background: #f8fafc; font-weight: 700; color: #334155;">মোট গ্রেড পয়েন্ট:</td>
<td style="padding: 4px 8px; border: 1px solid #cbd5e1; font-weight: 700; color: #0c2340;"><span id="cert-total-points">0.00</span></td>
</tr>
<tr>
<td style="padding: 4px 8px; border: 1px solid #cbd5e1; background: #f8fafc; font-weight: 700; color: #334155;">সেশন / রেজি. নং:</td>
<td style="padding: 4px 8px; border: 1px solid #cbd5e1; font-weight: 600; color: #0c2340;"><span id="cert-reg-session">২০২০-২১ (নিয়মিত)</span></td>
<td style="padding: 4px 8px; border: 1px solid #cbd5e1; background: #eff6ff; font-weight: 800; color: #1e3a8a;">চূড়ান্ত অর্জিত CGPA:</td>
<td style="padding: 4px 8px; border: 1px solid #cbd5e1; background: #eff6ff; font-size: 14.5px; font-weight: 800; color: #1e3a8a;"><span id="cert-cgpa">0.00</span> <span style="font-size: 10.5px; font-weight: normal; color: #64748b;">(আউট অব ৪.০০)</span></td>
</tr>
<tr>
<td style="padding: 4px 8px; border: 1px solid #cbd5e1; background: #f8fafc; font-weight: 700; color: #334155;">ডিগ্রি ও শিক্ষাবর্ষ:</td>
<td style="padding: 4px 8px; border: 1px solid #cbd5e1; font-weight: 700; color: #0c2340;"><span id="cert-program-name">স্নাতক (সম্মান) চার বছর</span></td>
<td style="padding: 4px 8px; border: 1px solid #cbd5e1; background: #f8fafc; font-weight: 700; color: #334155;">একাডেমিক শ্রেণি/ক্লাস:</td>
<td style="padding: 4px 8px; border: 1px solid #cbd5e1; font-weight: 800; color: #15803d;"><span id="cert-division">-</span></td>
</tr>
</table>
</div>
<!-- Official NU 10-Tier Grading Scale Key (Compact Institutional Strip) -->
<div style="position: relative; z-index: 2; background: #f8fafc; border: 1px solid #cbd5e1; border-radius: 4px; padding: 4px 6px; margin-bottom: 12px; font-size: 9.5px; color: #334155; line-height: 1.35; text-align: center;">
<strong style="color: #0c2340;">NU Grading Scale Key:</strong>
            80-100% <strong>A+</strong> (4.00) | 75-79% <strong>A</strong> (3.75) | 70-74% <strong>A-</strong> (3.50) | 65-69% <strong>B+</strong> (3.25) | 60-64% <strong>B</strong> (3.00) | 55-59% <strong>B-</strong> (2.75) | 50-54% <strong>C+</strong> (2.50) | 45-49% <strong>C</strong> (2.25) | 40-44% <strong>D</strong> (2.00) | 0-39% <strong>F</strong> (0.00)
          </div>
<!-- Examination Performance Table -->
<div style="position: relative; z-index: 2; margin-bottom: 12px;">
<table style="width: 100%; border-collapse: collapse; font-size: 12px; color: #0c2340;">
<thead>
<tr style="background: #1e3a8a; color: #ffffff; font-size: 11.5px;">
<th style="border: 1px solid #1e3a8a; padding: 5px 6px; text-align: center; width: 42px;">ক্রমিক</th>
<th style="border: 1px solid #1e3a8a; padding: 5px 8px; text-align: left;">শিক্ষাবর্ষ / কোর্স বিবরণ</th>
<th style="border: 1px solid #1e3a8a; padding: 5px 6px; text-align: center; width: 80px;">ক্রেডিট ঘণ্টা</th>
<th style="border: 1px solid #1e3a8a; padding: 5px 6px; text-align: center; width: 95px;">লেটার গ্রেড</th>
<th style="border: 1px solid #1e3a8a; padding: 5px 6px; text-align: center; width: 85px;">পয়েন্ট (GP)</th>
<th style="border: 1px solid #1e3a8a; padding: 5px 6px; text-align: center; width: 90px;">মোট পয়েন্ট</th>
</tr>
</thead>
<tbody id="cert-table-body">
<!-- Injected Dynamically via JS -->
</tbody>
<tfoot>
<tr style="background: #f1f5f9; font-weight: 800; border-top: 2px solid #0c2340; border-bottom: 2px solid #0c2340; font-size: 12px;">
<td colspan="2" style="border: 1px solid #cbd5e1; padding: 6px 8px; text-align: right; color: #0c2340;">সর্বমোট ফলাফল সারসংক্ষেপ:</td>
<td id="cert-foot-credits" style="border: 1px solid #cbd5e1; padding: 6px 6px; text-align: center; color: #0c2340;">128</td>
<td style="border: 1px solid #cbd5e1; padding: 6px 6px; text-align: center; color: #1e3a8a;">-</td>
<td id="cert-foot-cgpa" style="border: 1px solid #cbd5e1; padding: 6px 6px; text-align: center; color: #1e3a8a; font-size: 13px;">0.00</td>
<td id="cert-foot-points" style="border: 1px solid #cbd5e1; padding: 6px 6px; text-align: center; color: #0c2340;">0.00</td>
</tr>
</tfoot>
</table>
</div>
<!-- Official Sign-off & Verification Footer -->
<div style="position: relative; z-index: 2; display: flex; justify-content: space-between; align-items: center; margin-top: 15px; padding-top: 12px; border-top: 1px dashed #cbd5e1;">
<!-- Left: Platform Signature & Security Hash -->
<div style="font-size: 10px; color: #475569; line-height: 1.45; width: 33%;">
              উৎস প্ল্যাটফর্ম: <strong>HelpTrickBD.com</strong><br/>
              টুল: <strong>NU CGPA Calculator 2026</strong><br/>
              স্ট্যাটাস: <span style="color: #0369a1; font-weight: bold;">শিক্ষার্থী ব্যক্তিগত রেকর্ড (অনানুষ্ঠানিক)</span>
</div>
<!-- Center: Embossed Official Seal Stamp (SVG) -->
<div style="text-align: center; width: 33%;">
<div style="display: inline-block; border: 2px dashed #0284c7; border-radius: 50%; width: 70px; height: 70px; padding: 2px; box-sizing: border-box;">
<div style="border: 1px solid #0284c7; border-radius: 50%; width: 100%; height: 100%; display: flex; flex-direction: column; align-items: center; justify-content: center; font-size: 6.5px; font-weight: 700; color: #0369a1; text-transform: uppercase; line-height: 1.15;">
<span>HELPTRICKBD</span>
<span style="font-size: 7.5px; color: #b45309; letter-spacing: 0.5px;">- ONLINE -</span>
<span>CALCULATOR</span>
<span style="font-size: 5.5px; color: #15803d; letter-spacing: 0.5px;">STUDENT COPY</span>
</div>
</div>
</div>
<!-- Right: Auto-Generated Notice (No Signature) -->
<div style="text-align: center; width: 33%;">
<div style="border: 1px dashed #cbd5e1; border-radius: 6px; padding: 6px 8px; background: #f8fafc; font-size: 10px; line-height: 1.4; color: #475569;">
<div style="font-weight: 700; color: #b91c1c; font-size: 10px;">কম্পিউটার অটো-জেনারেটেড কপি</div>
<div style="font-weight: 600; color: #1e3a8a; font-size: 9px; margin-top: 1px;">HelpTrickBD.com সিস্টেম দ্বারা প্রস্তুতকৃত</div>
<div style="font-size: 8px; color: #64748b; margin-top: 2px;">(অনলাইন মূল্যায়ন — কোনো স্বাক্ষরের প্রয়োজন নেই)</div>
</div>
</div>
</div>
<!-- Bottom Legal & Ordinance Disclaimer -->
<div style="position: relative; z-index: 2; margin-top: 10px; font-size: 9.5px; color: #334155; line-height: 1.45; text-align: center; border: 1px solid #fecaca; background: #fef2f2; border-radius: 6px; padding: 7px 12px;">
<strong style="color: #b91c1c;">[জরুরি সতর্কবার্তা ও আইনি নোটিশ]:</strong> এই ফলাফল বিবরণীটি শিক্ষার্থীদের ব্যক্তিগত হিসাব ও সিজিপিএ পর্যালোচনার সুবিধার্থে <strong>HelpTrickBD.com</strong>-এর স্বয়ংক্রিয় অনলাইন ক্যালকুলেটর দ্বারা প্রস্তুতকৃত একটি অনানুষ্ঠানিক (Unofficial) কপি। এটি জাতীয় বিশ্ববিদ্যালয় গাজীপুর কর্তৃক ইস্যুকৃত কোনো মূল সনদ বা অফিসিয়াল ট্রান্সক্রিপ্ট নয়। সরকারি/বেসরকারি চাকরি, উচ্চশিক্ষা বা পাসপোর্ট আবেদনের ক্ষেত্রে জাতীয় বিশ্ববিদ্যালয় পরীক্ষা নিয়ন্ত্রণ দপ্তর কর্তৃক ইস্যুকৃত মূল সনদ ও সিলমোহরযুক্ত ট্রান্সক্রিপ্টই একমাত্র প্রযোজ্য ও আইনগতভাবে গ্রহণযোগ্য।
          </div>
</div>
</div>
<!-- ================= END CERTIFICATE PAPER ================= -->
</div>
</div>
</div>

        <!-- Educational Guide, Grading Scale & Comprehensive FAQ Section -->
        <section class="ht-cgpa-guide-section">
<figure style="margin: 0 0 25px 0; text-align: center;">
<img alt="জাতীয় বিশ্ববিদ্যালয় সিজিপিএ ক্যালকুলেটর ২০২৬" height="675" loading="eager" src="https://cdn.jsdelivr.net/gh/omarfarukitbd-spec/helptrickbdseo@main/assets/images/posts/nu_cgpa_calculator_honours_degree_masters_2026.webp" style="max-width: 100%; height: auto; border-radius: 10px; box-shadow: 0 4px 15px rgba(0,0,0,0.08); display: block; margin: 0 auto;" title="National University CGPA Calculator and Honours Grading Guide 2026" width="1200"/>
<figcaption style="font-family: 'SolaimanLipi', Arial, sans-serif; font-size: 14px; color: #64748b; margin-top: 10px; font-weight: 500;">
ছবি: জাতীয় বিশ্ববিদ্যালয় সিজিপিএ ক্যালকুলেটর, গ্রেডিং স্কেল ও একাডেমিক রেজাল্ট রূপরেখা
</figcaption>
</figure>
<p style="font-family: 'SolaimanLipi', sans-serif; font-size: 17px; line-height: 1.85; color: #1e293b; margin-bottom: 20px;">
জাতীয় বিশ্ববিদ্যালয় (National University, Bangladesh)-এর অধীনে স্নাতক (সম্মান), ডিগ্রি (পাস) এবং মাস্টার্স কোর্সের শিক্ষার্থীদের ফলাফল প্রকাশের পর সবচেয়ে গুরুত্বপূর্ণ বিষয় হলো সঠিক পদ্ধতিতে জিপিএ (GPA) ও সম্মিলিত সিজিপিএ (CGPA) গণনা করা। ক্রেডিট পদ্ধতির জটিল নিয়ম, নন-ক্রেডিট আবশ্যিক ইংরেজি বিষয় এবং ইনকোর্স ও ব্যবহারিক নম্বরের প্রভাবে ম্যানুয়ালি রেজাল্ট হিসাব করতে গিয়ে অধিকাংশ শিক্ষার্থীই বিভ্রান্ত হন। শিক্ষার্থীদের এই ভোগান্তি দূর করতে হেল্পট্রিকবিডি নিয়ে এলো <strong>সম্পূর্ণ ইন্টারেক্টিভ ও স্বয়ংক্রিয় জাতীয় বিশ্ববিদ্যালয় সিজিপিএ ক্যালকুলেটর ২০২৬</strong>। এই টুলের মাধ্যমে শিক্ষার্থী কেবল তাদের প্রাপ্ত লেটার গ্রেড বা নম্বর ইনপুট দিয়েই নয়, বরং ডিপার্টমেন্টভিত্তিক অফিসিয়াল সিলেবাস অটো-লোড এবং রেজাল্ট টেক্সট কপি-পেস্ট করে মুহূর্তে সঠিক সিজিপিএ ও ক্লাস (First Class / Second Class) যাচাই করতে পারবেন।
</p>
<!-- Quick Overview Callout Box -->
<div class="htbd-overview-box" style="background: #eff6ff; border-left: 5px solid #2563eb; border-radius: 8px; padding: 20px 24px; margin: 25px 0; font-family: 'SolaimanLipi', sans-serif;">
<h3 class="htbd-overview-title" style="margin: 0 0 10px 0; color: #1e3a8a; font-size: 19px; font-weight: 700;">এনইউ সিজিপিএ ক্যালকুলেটরের মূল বৈশিষ্ঠ্য একনজরে | Tool Overview</h3>
<p class="htbd-overview-text" style="margin: 0; color: #1e293b; font-size: 16px; line-height: 1.85;">
জাতীয় বিশ্ববিদ্যালয়ের ৪.০০ স্কেল ভিত্তিক এই ক্যালকুলেটরে রয়েছে: <strong>১. ইয়ার-ওয়াইজ লাইভ স্লাইডার সিজিপিএ ক্যালকুলেটর</strong>, <strong>২. ডিপার্টমেন্ট ও সিলেবাস অটো-লোড সুবিধা সহ বিষয়ভিত্তিক জিপিএ গণনা</strong>, <strong>৩. টার্গেট ফার্স্ট ক্লাস (৩.০০) প্ল্যানার</strong> এবং <strong>৪. মানোন্নয়ন (Improvement) পরীক্ষার প্রভাব সিমুলেটর</strong>। এছাড়া ফলাফল সরাসরি অফিসিয়াল প্রাতিষ্ঠানিক একাডেমিক ট্রান্সক্রিপ্ট ও গ্রেড শিট আকারে <strong>পেশাদার ১-পাতা A4 PDF</strong> হিসেবে প্রিন্ট বা সংরক্ষণের সুবিধা যুক্ত রয়েছে।
</p>
<div class="htbd-overview-source" style="margin-top: 12px; font-size: 14.5px; color: #1d4ed8; font-weight: 600;">
তথ্যসূত্র: জাতীয় বিশ্ববিদ্যালয় পরীক্ষা নিয়ন্ত্রণ দপ্তর ও স্নাতক (সম্মান) অর্ডিন্যান্স অনুযায়ী যাচাইকৃত
</div>
</div>

<!-- v1.4.11: Table of Contents (page had 8 H2 guide sections but no TOC) -->
<nav class="htbd-cgpa-toc" style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 10px; padding: 18px 22px; margin: 25px 0; font-family: 'SolaimanLipi', sans-serif;" aria-label="সূচিপত্র">
<h3 style="margin: 0 0 10px 0; color: #0c2340; font-size: 18px; font-weight: 700;">সূচিপত্র</h3>
<ol style="margin: 0; padding-left: 20px; color: #1e293b; font-size: 16px; line-height: 2;">
<li><a href="#cgpa-ki-kano" style="color: #1d4ed8; text-decoration: none;">সিজিপিএ ক্যালকুলেটর কী ও কেন এটি ব্যবহার করবেন?</a></li>
<li><a href="#cgpa-grading-scale" style="color: #1d4ed8; text-decoration: none;">জাতীয় বিশ্ববিদ্যালয়ের অফিসিয়াল গ্রেডিং স্কেল ও মার্কস বণ্টন ২০২৬</a></li>
<li><a href="#cgpa-class-division" style="color: #1d4ed8; text-decoration: none;">জাতীয় বিশ্ববিদ্যালয়ের ক্লাস ও ডিভিশন নির্ধারণের নীতিমালা</a></li>
<li><a href="#cgpa-formula" style="color: #1d4ed8; text-decoration: none;">সিজিপিএ হিসাব করার গাণিতিক ফর্মুলা ও বাস্তব উদাহরণ</a></li>
<li><a href="#cgpa-non-credit" style="color: #1d4ed8; text-decoration: none;">নন-ক্রেডিট আবশ্যিক ইংরেজি ও ব্যবহারিক বিষয়ের নিয়মাবলী</a></li>
<li><a href="#cgpa-improvement" style="color: #1d4ed8; text-decoration: none;">মানোন্নয়ন (Improvement) পরীক্ষার সুযোগ ও নিয়মাবলী</a></li>
<li><a href="#cgpa-tips" style="color: #1d4ed8; text-decoration: none;">সিজিপিএ ৩.০০+ (ফার্স্ট ক্লাস) পাওয়ার ৫টি পরীক্ষিত টিপস</a></li>
<li><a href="#cgpa-faq" style="color: #1d4ed8; text-decoration: none;">জাতীয় বিশ্ববিদ্যালয় সিজিপিএ সংক্রান্ত সচরাচর জিজ্ঞাসিত প্রশ্নাবলী (FAQ)</a></li>
</ol>
</nav>

<!-- ========================================================================== -->
<!-- INTERACTIVE WEB APPLICATION: NU ADVANCED CGPA CALCULATOR ENGINE           -->
<!-- ========================================================================== -->

<!-- ========================================================================== -->
<!-- INTERACTIVE LIVE PREVIEW MODAL: OFFICIAL A4 TRANSCRIPT & PDF CUSTOMIZER   -->
<!-- ========================================================================== -->

<!-- ========================================================================== -->
<!-- COMPREHENSIVE ACADEMIC CONTENT & SEO SHIELD (1,500+ WORDS)                 -->
<!-- ========================================================================== -->
<h2 class="htbd-content-h2" style="font-family: 'SolaimanLipi', sans-serif; color: #0c2340; font-size: 24px; font-weight: 700; margin: 40px 0 18px 0; border-left: 5px solid #1e3a8a; padding-left: 14px;" id="cgpa-ki-kano">
জাতীয় বিশ্ববিদ্যালয় সিজিপিএ ক্যালকুলেটর কী ও কেন এটি ব্যবহার করবেন?
</h2>
<p style="font-family: 'SolaimanLipi', sans-serif; font-size: 17px; line-height: 1.85; color: #1e293b; margin-bottom: 20px;">
জাতীয় বিশ্ববিদ্যালয়ের চার বছর মেয়াদি স্নাতক (সম্মান), তিন বছর মেয়াদি ডিগ্রি (পাস) এবং এক বা দুই বছর মেয়াদি মাস্টার্স পরীক্ষায় গ্রেডিং পদ্ধতি চালু হওয়ার পর থেকে শিক্ষার্থীদের ফলাফল মূল্যায়নে মৌলিক পরিবর্তন এসেছে। সনাতন শতকরা নম্বরের পরিবর্তে এখন প্রতিটি কোর্সে গ্রেড পয়েন্ট (GP) এবং বছর শেষে গ্রেড পয়েন্ট এভারেজ (GPA) হিসাব করা হয়। চার বছরের সমস্ত কোর্সের সমন্বয়ে তৈরি হয় ফাইনাল কিউমুলেটিভ গ্রেড পয়েন্ট এভারেজ বা সিজিপিএ (CGPA)।
</p>
<p style="font-family: 'SolaimanLipi', sans-serif; font-size: 17px; line-height: 1.85; color: #1e293b; margin-bottom: 20px;">
অনেক শিক্ষার্থী মনে করেন, চার বছরের জিপিএ সাধারণ যোগ করে চার দিয়ে ভাগ করলেই বুঝি সিজিপিএ পাওয়া যায়। এটি একটি মারাত্মক ভুল ধারণা! কারণ জাতীয় বিশ্ববিদ্যালয়ের প্রতিটি কোর্সের ক্রেডিট সমান নয়। কোনো কোর্স ৪ ক্রেডিটের (১০০ নম্বর), কোনো কোর্স ২ ক্রেডিটের (৫০ নম্বর) আবার ব্যবহারিক ও মৌখিক পরীক্ষার ক্রেডিট ভিন্ন হয়ে থাকে। ক্রেডিট-ওয়েটেড পদ্ধতি অনুসরণ না করে হিসাব করলে ফলাফলে বড় ধরনের গরমিল দেখা দেয়। হেল্পট্রিকবিডির এই ক্যালকুলেটরটি জাতীয় বিশ্ববিদ্যালয়ের অফিসিয়াল একাডেমিক অর্ডিন্যান্স অনুযায়ী <strong>ক্রেডিট-ওয়েটেড এভারেজ ফর্মুলা</strong> ব্যবহার করে স্বয়ংক্রিয়ভাবে ক্রেডিট-ওয়েটেড সিজিপিএ নির্ণয় করে।
</p>
<p style="font-family: 'SolaimanLipi', sans-serif; font-size: 17px; line-height: 1.85; color: #1e293b; margin-bottom: 20px;">
<strong>সরাসরি ফ্র্যাকশনাল বা কাস্টম পয়েন্ট ইনপুট সুবিধা:</strong> অনেক শিক্ষার্থী তাদের নির্দিষ্ট পরীক্ষার নম্বরপত্র অনুযায়ী বা মানোন্নয়ন পর্যালোচনায় ড্রপডাউনের বাঁধা-ধরা লেটার গ্রেডের বাইরে যেকোনো কাস্টম ফ্র্যাকশনাল পয়েন্ট (যেমন: ৩.৪৫, ৩.১৮, ৩.৬০ ইত্যাদি) সরাসরি ইনপুট দিয়ে রেজাল্ট পরীক্ষা করতে চান। হেল্পট্রিকবিডি ক্যালকুলেটরে প্রতিটি কোর্সের পাশে <strong>লেটার গ্রেডের পাশাপাশি সরাসরি পয়েন্ট (GP) টাইপ করার স্বতন্ত্র ঘর</strong> যুক্ত করা হয়েছে। লেটার গ্রেড সিলেক্ট করলে পয়েন্ট ঘরে স্বয়ংক্রিয়ভাবে পয়েন্ট বসে যায়, আবার সরাসরি পয়েন্ট টাইপ করলে ক্যালকুলেটর স্বয়ংক্রিয়ভাবে সেই সুনির্দিষ্ট পয়েন্টের ভিত্তিতে ক্রেডিট-ওয়েটেড সিজিপিএ নির্ধারণ করে।
</p>
<h2 class="htbd-content-h2" style="font-family: 'SolaimanLipi', sans-serif; color: #0c2340; font-size: 24px; font-weight: 700; margin: 40px 0 18px 0; border-left: 5px solid #1e3a8a; padding-left: 14px;" id="cgpa-grading-scale">
জাতীয় বিশ্ববিদ্যালয়ের অফিসিয়াল গ্রেডিং স্কেল ও মার্কস বণ্টন ২০২৬
</h2>
<p style="font-family: 'SolaimanLipi', sans-serif; font-size: 17px; line-height: 1.85; color: #1e293b; margin-bottom: 20px;">
জাতীয় বিশ্ববিদ্যালয় ইউজার ফ্রেন্ডলি ৪.০০ পয়েন্ট স্কেল অনুসরণ করে। নিম্নে শতকরা নম্বর, লেটার গ্রেড এবং অর্জিত গ্রেড পয়েন্টের অফিসিয়াল তালিকা প্রদান করা হলো:
</p>
<!-- Grading Table -->
<div style="overflow-x: auto; margin: 25px 0;">
<table class="htbd-grade-table" style="width: 100%; min-width: 560px; border-collapse: collapse; font-family: 'SolaimanLipi', sans-serif; font-size: 16px; text-align: center; border: 1px solid #cbd5e1;">
<thead>
<tr style="background: #1e3a8a; color: #ffffff;">
<th style="padding: 12px; border: 1px solid #cbd5e1;">শতকরা নম্বর (%)</th>
<th style="padding: 12px; border: 1px solid #cbd5e1;">লেটার গ্রেড (Letter Grade)</th>
<th style="padding: 12px; border: 1px solid #cbd5e1;">গ্রেড পয়েন্ট (GP)</th>
<th style="padding: 12px; border: 1px solid #cbd5e1;">একাডেমিক মূল্যায়ন</th>
</tr>
</thead>
<tbody>
<tr class="row-even" style="background: #ffffff;">
<td style="padding: 10px; border: 1px solid #cbd5e1; font-weight: 600;">৮০% থেকে ১০০%</td>
<td style="padding: 10px; border: 1px solid #cbd5e1; font-weight: 700; color: #15803d;">A+</td>
<td style="padding: 10px; border: 1px solid #cbd5e1; font-weight: 700;">4.00</td>
<td style="padding: 10px; border: 1px solid #cbd5e1;">অসামান্য (Outstanding)</td>
</tr>
<tr class="row-odd" style="background: #f8fafc;">
<td style="padding: 10px; border: 1px solid #cbd5e1; font-weight: 600;">৭৫% থেকে ৭৯%</td>
<td style="padding: 10px; border: 1px solid #cbd5e1; font-weight: 700; color: #16a34a;">A</td>
<td style="padding: 10px; border: 1px solid #cbd5e1; font-weight: 700;">3.75</td>
<td style="padding: 10px; border: 1px solid #cbd5e1;">চমৎকার (Excellent)</td>
</tr>
<tr class="row-even" style="background: #ffffff;">
<td style="padding: 10px; border: 1px solid #cbd5e1; font-weight: 600;">৭০% থেকে ৭৪%</td>
<td style="padding: 10px; border: 1px solid #cbd5e1; font-weight: 700; color: #22c55e;">A-</td>
<td style="padding: 10px; border: 1px solid #cbd5e1; font-weight: 700;">3.50</td>
<td style="padding: 10px; border: 1px solid #cbd5e1;">অতি উত্তম (Very Good)</td>
</tr>
<tr class="row-odd" style="background: #f8fafc;">
<td style="padding: 10px; border: 1px solid #cbd5e1; font-weight: 600;">৬৫% থেকে ৬৯%</td>
<td style="padding: 10px; border: 1px solid #cbd5e1; font-weight: 700; color: #2563eb;">B+</td>
<td style="padding: 10px; border: 1px solid #cbd5e1; font-weight: 700;">3.25</td>
<td style="padding: 10px; border: 1px solid #cbd5e1;">উত্তম (Good)</td>
</tr>
<tr class="row-even" style="background: #ffffff;">
<td style="padding: 10px; border: 1px solid #cbd5e1; font-weight: 600;">৬০% থেকে ৬৪%</td>
<td style="padding: 10px; border: 1px solid #cbd5e1; font-weight: 700; color: #3b82f6;">B</td>
<td style="padding: 10px; border: 1px solid #cbd5e1; font-weight: 700;">3.00</td>
<td style="padding: 10px; border: 1px solid #cbd5e1;">সন্তোষজনক (Satisfactory)</td>
</tr>
<tr class="row-odd" style="background: #f8fafc;">
<td style="padding: 10px; border: 1px solid #cbd5e1; font-weight: 600;">৫৫% থেকে ৫৯%</td>
<td style="padding: 10px; border: 1px solid #cbd5e1; font-weight: 700; color: #6366f1;">B-</td>
<td style="padding: 10px; border: 1px solid #cbd5e1; font-weight: 700;">2.75</td>
<td style="padding: 10px; border: 1px solid #cbd5e1;">পাস (Above Average)</td>
</tr>
<tr class="row-even" style="background: #ffffff;">
<td style="padding: 10px; border: 1px solid #cbd5e1; font-weight: 600;">৫০% থেকে ৫৪%</td>
<td style="padding: 10px; border: 1px solid #cbd5e1; font-weight: 700; color: #d97706;">C+</td>
<td style="padding: 10px; border: 1px solid #cbd5e1; font-weight: 700;">2.50</td>
<td style="padding: 10px; border: 1px solid #cbd5e1;">সাধারণ (Average)</td>
</tr>
<tr class="row-odd" style="background: #f8fafc;">
<td style="padding: 10px; border: 1px solid #cbd5e1; font-weight: 600;">৪৫% থেকে ৪৯%</td>
<td style="padding: 10px; border: 1px solid #cbd5e1; font-weight: 700; color: #ea580c;">C</td>
<td style="padding: 10px; border: 1px solid #cbd5e1; font-weight: 700;">2.25</td>
<td style="padding: 10px; border: 1px solid #cbd5e1;">গড়পড়তা (Below Average)</td>
</tr>
<tr class="row-even" style="background: #ffffff;">
<td style="padding: 10px; border: 1px solid #cbd5e1; font-weight: 600;">৪০% থেকে ৪৪%</td>
<td style="padding: 10px; border: 1px solid #cbd5e1; font-weight: 700; color: #dc2626;">D</td>
<td style="padding: 10px; border: 1px solid #cbd5e1; font-weight: 700;">2.00</td>
<td style="padding: 10px; border: 1px solid #cbd5e1;">নিম্ন পাস (Poor Pass)</td>
</tr>
<tr class="row-fail" style="background: #fef2f2;">
<td style="padding: 10px; border: 1px solid #cbd5e1; font-weight: 600; color: #b91c1c;">৪০% এর নিচে</td>
<td style="padding: 10px; border: 1px solid #cbd5e1; font-weight: 700; color: #b91c1c;">F</td>
<td style="padding: 10px; border: 1px solid #cbd5e1; font-weight: 700; color: #b91c1c;">0.00</td>
<td style="padding: 10px; border: 1px solid #cbd5e1; color: #b91c1c;">অকৃতকার্য (Fail)</td>
</tr>
</tbody>
</table>
</div>
<h2 class="htbd-content-h2" style="font-family: 'SolaimanLipi', sans-serif; color: #0c2340; font-size: 24px; font-weight: 700; margin: 40px 0 18px 0; border-left: 5px solid #1e3a8a; padding-left: 14px;" id="cgpa-class-division">
জাতীয় বিশ্ববিদ্যালয়ের ক্লাস ও ডিভিশন নির্ধারণের নীতিমালা
</h2>
<p style="font-family: 'SolaimanLipi', sans-serif; font-size: 17px; line-height: 1.85; color: #1e293b; margin-bottom: 20px;">
চাকরির পরীক্ষায় বা উচ্চশিক্ষায় আবেদনের ক্ষেত্রে প্রায়ই প্রথম শ্রেণি (First Class) বা দ্বিতীয় শ্রেণি (Second Class)-এর প্রয়োজনীয়তা উল্লেখ থাকে। জাতীয় বিশ্ববিদ্যালয়ের সিজিপিএ স্কেল অনুযায়ী ক্লাস সমতুল্যতার নিয়ম নিম্নরূপ:
</p>
<ul style="font-family: 'SolaimanLipi', sans-serif; font-size: 17px; line-height: 1.85; color: #1e293b; margin-bottom: 25px; padding-left: 20px;">
<li style="margin-bottom: 10px;"><strong>প্রথম শ্রেণি (First Class):</strong> সিজিপিএ ৩.০০ থেকে ৪.০০ (CGPA 3.00 to 4.00)। এই রেঞ্জে থাকলে শিক্ষার্থী প্রথম শ্রেণিতে উত্তীর্ণ বলে গণ্য হন।</li>
<li style="margin-bottom: 10px;"><strong>দ্বিতীয় শ্রেণি (Second Class):</strong> সিজিপিএ ২.২৫ থেকে ২.৯৯ (CGPA 2.25 to 2.99)। জাতীয় বিশ্ববিদ্যালয়ের সিংহভাগ শিক্ষার্থী এই ক্যাটাগরিতে অন্তর্ভুক্ত হন।</li>
<li style="margin-bottom: 10px;"><strong>তৃতীয় শ্রেণি (Third Class):</strong> সিজিপিএ ২.০০ থেকে ২.২৪ (CGPA 2.00 to 2.24)। এটি স্নাতক ডিগ্রি অর্জনের ন্যূনতম পাস মানদণ্ড।</li>
<li style="margin-bottom: 10px;"><strong>ফেল বা ডিগ্রি অপ্রাপ্ত:</strong> সিজিপিএ ২.০০-এর নিচে পেলে শিক্ষার্থী কোনো ডিগ্রি অর্জন করতে পারবেন না। তাকে মানোন্নয়ন বা রি-অ্যাডমিশনের মাধ্যমে সিজিপিএ ২.০০ এ উন্নীত করতে হবে।</li>
</ul>
<h2 class="htbd-content-h2" style="font-family: 'SolaimanLipi', sans-serif; color: #0c2340; font-size: 24px; font-weight: 700; margin: 40px 0 18px 0; border-left: 5px solid #1e3a8a; padding-left: 14px;" id="cgpa-formula">
সিজিপিএ হিসাব করার গাণিতিক ফর্মুলা ও বাস্তব উদাহরণ
</h2>
<p style="font-family: 'SolaimanLipi', sans-serif; font-size: 17px; line-height: 1.85; color: #1e293b; margin-bottom: 20px;">
জাতীয় বিশ্ববিদ্যালয়ের অফিসিয়াল রেগুলেশন অনুযায়ী সিজিপিএ নির্ণয়ের মৌলিক সূত্রটি হলো:
</p>
<div class="htbd-formula-box" style="background: #f1f5f9; border-radius: 8px; padding: 18px; margin: 20px 0; font-family: monospace; font-size: 15px; color: #0f172a; text-align: center; border: 1px solid #cbd5e1;">
CGPA = (মোট অর্জিত ক্রেডিট পয়েন্টের যোগফল) ÷ (মোট ক্রেডিট সংখ্যা)
<br/><br/>
বা, CGPA = ∑ (Credit × Grade Point) ÷ ∑ (Total Credits)
</div>
<p style="font-family: 'SolaimanLipi', sans-serif; font-size: 17px; line-height: 1.85; color: #1e293b; margin-bottom: 20px;">
<strong>বাস্তব উদাহরণ:</strong> ধরি একজন শিক্ষার্থী চার বছরে মোট ১২৮ ক্রেডিট সম্পন্ন করেছেন।<br/>
• ১ম বর্ষ (৩২ ক্রেডিট): জিপিএ ৩.১০ → ক্রেডিট পয়েন্ট = ৩২ × ৩.১০ = ৯৯.২০<br/>
• ২য় বর্ষ (৩২ ক্রেডিট): জিপিএ ২.৮৫ → ক্রেডিট পয়েন্ট = ৩২ × ২.৮৫ = ৯১.২০<br/>
• ৩য় বর্ষ (৩২ ক্রেডিট): জিপিএ ৩.০০ → ক্রেডিট পয়েন্ট = ৩২ × ৩.০০ = ৯৬.০০<br/>
• ৪র্থ বর্ষ (৩২ ক্রেডিট): জিপিএ ৩.২০ → ক্রেডিট পয়েন্ট = ৩২ × ৩.২০ = ১০২.৪০<br/>
<strong>মোট ক্রেডিট পয়েন্ট:</strong> ৯৯.২০ + ৯১.২০ + ৯৬.০০ + ১০২.৪০ = ৩৮৮.৮০<br/>
<strong>ফাইনাল CGPA:</strong> ৩৮৮.৮০ ÷ ১২৮ = <strong>৩.০৪ (First Class / ১ম শ্রেণি)</strong>!
</p>
<h2 class="htbd-content-h2" style="font-family: 'SolaimanLipi', sans-serif; color: #0c2340; font-size: 24px; font-weight: 700; margin: 40px 0 18px 0; border-left: 5px solid #1e3a8a; padding-left: 14px;" id="cgpa-non-credit">
নন-ক্রেডিট আবশ্যিক ইংরেজি ও ব্যবহারিক বিষয়ের নিয়মাবলী
</h2>
<p style="font-family: 'SolaimanLipi', sans-serif; font-size: 17px; line-height: 1.85; color: #1e293b; margin-bottom: 20px;">
অনার্স ২য় বর্ষের শিক্ষার্থীদের জন্য ১০০ নম্বরের একটি <strong>ইংরেজি আবশ্যিক (Non-Credit English, কোর্স কোড: ২২১১০৯)</strong> বিষয় থাকে। অনেক শিক্ষার্থীই দুশ্চিন্তায় থাকেন যে এতে খারাপ করলে বুঝি সিজিপিএ কমে যাবে। জাতীয় বিশ্ববিদ্যালয়ের স্পষ্ট নীতিমালা হলো:
</p>
<ul style="font-family: 'SolaimanLipi', sans-serif; font-size: 17px; line-height: 1.85; color: #1e293b; margin-bottom: 25px; padding-left: 20px;">
<li style="margin-bottom: 10px;">ইংরেজি আবশ্যিক বিষয়ের ক্রেডিট সংখ্যা ০ (Zero Credit)। তাই এতে আপনি A+ পান বা D পান, এটি আপনার বার্ষিক জিপিএ বা সার্বিক সিজিপিএ-তে কোনো প্রভাব ফেলবে না।</li>
<li style="margin-bottom: 10px;">তবে পরীক্ষায় ন্যূনতম ৩৩ নম্বর পেয়ে পাস করা বাধ্যতামূলক। কোনো শিক্ষার্থী ফেল করলে তাকে পরবর্তী ব্যাচের সাথে পরীক্ষা দিয়ে পাস করতে হবে। অন্যথায় অনার্স পাসের চূড়ান্ত মূল সনদপত্র প্রদান করা হবে না।</li>
<li style="margin-bottom: 10px;">বিজ্ঞান অনুষদের ক্ষেত্রে ব্যবহারিক ও ইনকোর্স পরীক্ষা অত্যন্ত গুরুত্বপূর্ণ। প্র্যাকটিক্যাল সাধারণত ২ বা ৪ ক্রেডিটের হয়ে থাকে এবং এতে ভালো গ্রেড (A বা A+) পাওয়া অপেক্ষাকৃত সহজ, যা সামগ্রিক সিজিপিএ অনেক বৃদ্ধি করে।</li>
</ul>
<h2 class="htbd-content-h2" style="font-family: 'SolaimanLipi', sans-serif; color: #0c2340; font-size: 24px; font-weight: 700; margin: 40px 0 18px 0; border-left: 5px solid #1e3a8a; padding-left: 14px;" id="cgpa-improvement">
মানোন্নয়ন (Improvement) পরীক্ষার সুযোগ ও নিয়মাবলী
</h2>
<p style="font-family: 'SolaimanLipi', sans-serif; font-size: 17px; line-height: 1.85; color: #1e293b; margin-bottom: 20px;">
জাতীয় বিশ্ববিদ্যালয়ে কোনো কোর্সে খারাপ ফলাফল হলে তা শুধরে নেওয়ার জন্য মানোন্নয়ন পরীক্ষার সুযোগ রয়েছে। তবে এর কিছু কড়া নিয়ম রয়েছে:
</p>
<ul style="font-family: 'SolaimanLipi', sans-serif; font-size: 17px; line-height: 1.85; color: #1e293b; margin-bottom: 25px; padding-left: 20px;">
<li style="margin-bottom: 10px;">C, C+ অথবা D গ্রেড প্রাপ্ত কোর্সে মানোন্নয়ন পরীক্ষা দেওয়া যায় — এক শিক্ষাবর্ষে সর্বোচ্চ ২টি কোর্সে। F গ্রেডের কোর্সেও মানোন্নয়ন দেওয়া যায়।</li>
<li style="margin-bottom: 10px;">মানোন্নয়নে B+ সর্বোচ্চ সীমা আর প্রযোজ্য নয় — জাতীয় বিশ্ববিদ্যালয়ের সংশোধিত রেগুলেশন ২০২৫ (ধারা ১৪) অনুযায়ী প্রাপ্ত নম্বর অনুযায়ী গ্রেড গণনা করা হয়; শুধু F গ্রেডের কোর্সে মানোন্নয়নের সর্বোচ্চ গ্রেড A-।</li>
<li style="margin-bottom: 10px;">যদি মানোন্নয়ন পরীক্ষায় আগের চেয়ে কম গ্রেড আসে, তবে পূর্বের ভালো গ্রেডটিই রেজাল্ট শিটে বহাল রাখা হয়।</li>
</ul>
<h2 class="htbd-content-h2" style="font-family: 'SolaimanLipi', sans-serif; color: #0c2340; font-size: 24px; font-weight: 700; margin: 40px 0 18px 0; border-left: 5px solid #1e3a8a; padding-left: 14px;" id="cgpa-tips">
সিজিপিএ ৩.০০+ (ফার্স্ট ক্লাস) পাওয়ার ৫টি পরীক্ষিত টিপস
</h2>
<p style="font-family: 'SolaimanLipi', sans-serif; font-size: 17px; line-height: 1.85; color: #1e293b; margin-bottom: 20px;">
চার বছরের অনার্স যাত্রায় অনেক শিক্ষার্থী শুরুতে হেলাফেলা করে ৩য় বা ৪র্থ বর্ষে এসে সিজিপিএ বাড়ানোর জন্য দিশেহারা হয়ে পড়েন। আপনি যদি প্রথম শ্রেণি পেতে চান, তবে নিচের কৌশলগুলো মেনে চলুন:
</p>
<ol style="font-family: 'SolaimanLipi', sans-serif; font-size: 17px; line-height: 1.85; color: #1e293b; margin-bottom: 25px; padding-left: 20px;">
<li style="margin-bottom: 12px;"><strong>১ম ও ২য় বর্ষ থেকেই ৩.০০ টার্গেট রাখুন:</strong> ১ম ও ২য় বর্ষের সিলেবাস তুলনামূলক সহজ থাকে। এই সময়ে ৩.১০ থেকে ৩.২০ তুলে রাখলে পরবর্তীতে কঠিন বর্ষগুলোতেও সিজিপিএ ৩.০০-এর নিচে নামে না।</li>
<li style="margin-bottom: 12px;"><strong>ইনকোর্স ও টার্ম পেপারে পুরো নম্বর আদায়:</strong> প্রতিটি ১০০ নম্বরের বিষয়ে ২০ নম্বর থাকে ইনকোর্সে। শিক্ষকদের সাথে সুসম্পর্ক রেখে এবং যথাসময়ে অ্যাসাইনমেন্ট জমা দিয়ে ২০-এ ১৮-১৯ পাওয়ার লক্ষ্য রাখুন।</li>
<li style="margin-bottom: 12px;"><strong>'F' গ্রেড কোনো অবস্থাতেই আসতে দেবেন না:</strong> একটি F গ্রেড পুরো বছরের জিপিএ এক ধাক্কায় ০.৪০ থেকে ০.৫০ নামিয়ে দেয়। ন্যূনতম পাস মার্ক ৪০ অবশ্যই অর্জন করতে হবে।</li>
<li style="margin-bottom: 12px;"><strong>বোর্ডের বিগত ৫ বছরের প্রশ্ন বিশ্লেষণ:</strong> জাতীয় বিশ্ববিদ্যালয়ের লিখিত পরীক্ষায় প্রায় ৬০-৭০% প্রশ্ন পূর্ববর্তী বছরগুলোর ফাইনাল পরীক্ষা থেকে ঘুরেফিরে আসে। বিগত ৫ বছরের বোর্ড প্রশ্ন মুখস্থের মতো আয়ত্ত করুন।</li>
<li style="margin-bottom: 12px;"><strong>পয়েন্ট ও চার্টভিত্তিক খাতা উপস্থাপন:</strong> ঢালাও প্যারাগ্রাফ লেখার চেয়ে উত্তরপত্রে সাব-হেডিং, বুলেট পয়েন্ট, ডাটা চার্ট এবং উদ্ধৃতি ব্যবহার করলে পরীক্ষক সর্বোচ্চ নম্বর প্রদান করেন।</li>
</ol>
<h2 class="htbd-content-h2" style="font-family: 'SolaimanLipi', sans-serif; color: #0c2340; font-size: 24px; font-weight: 700; margin: 40px 0 18px 0; border-left: 5px solid #1e3a8a; padding-left: 14px;" id="cgpa-faq">
জাতীয় বিশ্ববিদ্যালয় সিজিপিএ সংক্রান্ত সচরাচর জিজ্ঞাসিত প্রশ্নাবলী (FAQ)
</h2>
<!-- FAQ 1 -->
<div class="htbd-faq-item" style="background: #ffffff; border: 1px solid #e2e8f0; border-radius: 8px; padding: 18px 20px; margin-bottom: 14px; font-family: 'SolaimanLipi', sans-serif;">
<h3 style="margin: 0 0 8px 0; color: #1e3a8a; font-size: 18px; font-weight: 700;">১. জাতীয় বিশ্ববিদ্যালয়ে মোট কত ক্রেডিট সম্পন্ন করতে হয়?</h3>
<p style="margin: 0; color: #334155; font-size: 16px; line-height: 1.8;">
চার বছর মেয়াদি স্নাতক (সম্মান) কোর্সে সাধারণত প্রতি শিক্ষাবর্ষে ৩২ ক্রেডিট করে ৪ বছরে সর্বমোট ১২৮ ক্রেডিট সম্পন্ন করতে হয়। কিছু বিশেষ বিভাগে ব্যবহারিক বেশি থাকায় ক্রেডিট সামান্য কম-বেশি হতে পারে।
</p>
</div>
<!-- FAQ 2 -->
<div class="htbd-faq-item" style="background: #ffffff; border: 1px solid #e2e8f0; border-radius: 8px; padding: 18px 20px; margin-bottom: 14px; font-family: 'SolaimanLipi', sans-serif;">
<h3 style="margin: 0 0 8px 0; color: #1e3a8a; font-size: 18px; font-weight: 700;">২. সিজিপিএ কত পেলে ১ম শ্রেণি বা ফার্স্ট ক্লাস গণ্য হবে?</h3>
<p style="margin: 0; color: #334155; font-size: 16px; line-height: 1.8;">
জাতীয় বিশ্ববিদ্যালয়ের নিয়ম অনুযায়ী ফাইনাল সিজিপিএ ৩.০০ (CGPA 3.00) বা তার বেশি অর্জন করলে তা প্রথম শ্রেণি (First Class) হিসেবে গণ্য হবে। ২.২৫ থেকে ২.৯৯ পর্যন্ত ২য় শ্রেণি এবং ২.০০ থেকে ২.২৪ পর্যন্ত ৩য় শ্রেণি।
</p>
</div>
<!-- FAQ 3 -->
<div class="htbd-faq-item" style="background: #ffffff; border: 1px solid #e2e8f0; border-radius: 8px; padding: 18px 20px; margin-bottom: 14px; font-family: 'SolaimanLipi', sans-serif;">
<h3 style="margin: 0 0 8px 0; color: #1e3a8a; font-size: 18px; font-weight: 700;">৩. নন-ক্রেডিট ইংরেজি ফেল করলে কি সিজিপিএ ক্ষতিগ্রস্ত হবে?</h3>
<p style="margin: 0; color: #334155; font-size: 16px; line-height: 1.8;">
না, ইংরেজি আবশ্যিক বিষয়ের ক্রেডিট সংখ্যা ০ হওয়ায় এতে অর্জিত গ্রেড সিজিপিএ গণনায় কোনো প্রভাব ফেলে না। তবে স্নাতক সনদ পাওয়ার জন্য এতে ন্যূনতম ৩৩ নম্বর পেয়ে পাস করা বাধ্যতামূলক।
</p>
</div>
<!-- FAQ 4 -->
<div class="htbd-faq-item" style="background: #ffffff; border: 1px solid #e2e8f0; border-radius: 8px; padding: 18px 20px; margin-bottom: 14px; font-family: 'SolaimanLipi', sans-serif;">
<h3 style="margin: 0 0 8px 0; color: #1e3a8a; font-size: 18px; font-weight: 700;">৪. ইমপ্রুভমেন্ট পরীক্ষা দিলে কি A+ পাওয়া সম্ভব?</h3>
<p style="margin: 0; color: #334155; font-size: 16px; line-height: 1.8;">
হ্যাঁ, সম্ভব — C, C+ বা D গ্রেডের কোর্সে মানোন্নয়ন দিলে প্রাপ্ত নম্বর অনুযায়ী A+ পর্যন্ত পাওয়া যায়; B+ সর্বোচ্চ সীমা আর প্রযোজ্য নয় (সংশোধিত রেগুলেশন ২০২৫, ধারা ১৪)। শুধু F গ্রেডের কোর্সে মানোন্নয়নের সর্বোচ্চ গ্রেড A-।
</p>
</div>
<!-- FAQ 5 -->
<div class="htbd-faq-item" style="background: #ffffff; border: 1px solid #e2e8f0; border-radius: 8px; padding: 18px 20px; margin-bottom: 14px; font-family: 'SolaimanLipi', sans-serif;">
<h3 style="margin: 0 0 8px 0; color: #1e3a8a; font-size: 18px; font-weight: 700;">৫. কোনো বর্ষে এফ (F) গ্রেড থাকলে কি সিজিপিএ হিসাব করা সম্ভব?</h3>
<p style="margin: 0; color: #334155; font-size: 16px; line-height: 1.8;">
হ্যাঁ, তবে F গ্রেডের গ্রেড পয়েন্ট হলো ০.০০। এটি মোট ক্রেডিটের সাথে যুক্ত হয়ে গড় সিজিপিএ ব্যাপকভাবে হ্রাস করে। পরবর্তী বর্ষে পরীক্ষা দিয়ে F গ্রেড ক্লিয়ার করলে নতুন গ্রেড পয়েন্ট যুক্ত হয়ে সিজিপিএ বৃদ্ধি পাবে।
</p>
</div>
<!-- FAQ 6 -->
<div class="htbd-faq-item" style="background: #ffffff; border: 1px solid #e2e8f0; border-radius: 8px; padding: 18px 20px; margin-bottom: 14px; font-family: 'SolaimanLipi', sans-serif;">
<h3 style="margin: 0 0 8px 0; color: #1e3a8a; font-size: 18px; font-weight: 700;">৬. ডিগ্রি (পাস) কোর্সের সিজিপিএ কি একই নিয়মে গণনা করা হয়?</h3>
<p style="margin: 0; color: #334155; font-size: 16px; line-height: 1.8;">
হ্যাঁ, ডিগ্রি (পাস) কোর্সেও একই ৪.০০ পয়েন্ট গ্রেডিং স্কেল কার্যকর। তবে ডিগ্রি কোর্স ৩ বছর মেয়াদি হওয়ায় মোট ক্রেডিট সাধারণত ৮৪ থেকে ৯০ ক্রেডিট হয়ে থাকে।
</p>
</div>
<!-- FAQ 7 -->
<div class="htbd-faq-item" style="background: #ffffff; border: 1px solid #e2e8f0; border-radius: 8px; padding: 18px 20px; margin-bottom: 14px; font-family: 'SolaimanLipi', sans-serif;">
<h3 style="margin: 0 0 8px 0; color: #1e3a8a; font-size: 18px; font-weight: 700;">৭. পরবর্তী বর্ষে প্রমোশনের জন্য ন্যূনতম সিজিপিএ কত লাগে?</h3>
<p style="margin: 0; color: #334155; font-size: 16px; line-height: 1.8;">
অনার্স ১ম বর্ষ থেকে ২য় বর্ষে প্রমোশনের জন্য ন্যূনতম CGPA ২.০০ এবং ৩টি বিষয়ে পাস প্রয়োজন। পরবর্তী বর্ষগুলোতেও ন্যূনতম সিজিপিএ ২.০০ বজায় রাখা আবশ্যক।
</p>
</div>
<!-- FAQ 8 -->
<div class="htbd-faq-item" style="background: #ffffff; border: 1px solid #e2e8f0; border-radius: 8px; padding: 18px 20px; margin-bottom: 14px; font-family: 'SolaimanLipi', sans-serif;">
<h3 style="margin: 0 0 8px 0; color: #1e3a8a; font-size: 18px; font-weight: 700;">৮. মাস্টার্স কোর্সের সিজিপিএ স্কেল কি ভিন্ন?</h3>
<p style="margin: 0; color: #334155; font-size: 16px; line-height: 1.8;">
না, মাস্টার্স ফাইনাল বা প্রিলিমিনারিতেও একই ৪.০০ স্কেল ব্যবহৃত হয়। মাস্টার্স ফাইনালে সাধারণত ৩২ থেকে ৩৬ ক্রেডিট সম্পন্ন করতে হয়।
</p>
</div>
<!-- FAQ 9 -->
<div class="htbd-faq-item" style="background: #ffffff; border: 1px solid #e2e8f0; border-radius: 8px; padding: 18px 20px; margin-bottom: 14px; font-family: 'SolaimanLipi', sans-serif;">
<h3 style="margin: 0 0 8px 0; color: #1e3a8a; font-size: 18px; font-weight: 700;">৯. হেল্পট্রিকবিডি সিজিপিএ ক্যালকুলেটর কি অফলাইনে কাজ করে?</h3>
<p style="margin: 0; color: #334155; font-size: 16px; line-height: 1.8;">
হ্যাঁ, একবার পেজটি লোড হয়ে গেলে কোনো ইন্টারনেট সংযোগ ছাড়াও এটি ক্লায়েন্ট-সাইড জাভাস্ক্রিপ্ট দ্বারা সম্পূর্ণ অফলাইনে মসৃণভাবে গণনা সম্পন্ন করতে পারে।
</p>
</div>
<!-- FAQ 10 -->
<div class="htbd-faq-item" style="background: #ffffff; border: 1px solid #e2e8f0; border-radius: 8px; padding: 18px 20px; margin-bottom: 14px; font-family: 'SolaimanLipi', sans-serif;">
<h3 style="margin: 0 0 8px 0; color: #1e3a8a; font-size: 18px; font-weight: 700;">১০. ব্রাউজার রিফ্রেশ করলে কি আমার ইনপুট করা রেজাল্ট মুছে যাবে?</h3>
<p style="margin: 0; color: #334155; font-size: 16px; line-height: 1.8;">
না! আমাদের ক্যালকুলেটরে লোকাল স্টোরেজ (LocalStorage) অটো-সেভ ব্যবস্থা রয়েছে। ফলে পেজ বন্ধ বা রিফ্রেশ করলেও আপনার ইনপুট করা রেজাল্ট সম্পূর্ণ নিরাপদ সংরক্ষিত থাকবে।
</p>
</div>
<!-- FAQ 11 -->
<div class="htbd-faq-item" style="background: #ffffff; border: 1px solid #e2e8f0; border-radius: 8px; padding: 18px 20px; margin-bottom: 25px; font-family: 'SolaimanLipi', sans-serif;">
<h3 style="margin: 0 0 8px 0; color: #1e3a8a; font-size: 18px; font-weight: 700;">১১. লেটার গ্রেড ছাড়া কি সরাসরি দশমিক বা কাস্টম পয়েন্ট দিয়ে সিজিপিএ হিসাব করা যায়?</h3>
<p style="margin: 0; color: #334155; font-size: 16px; line-height: 1.8;">
হ্যাঁ! আমাদের ক্যালকুলেটরে প্রতিটি বিষয়ের জন্য লেটার গ্রেডের পাশাপাশি "পয়েন্ট (GP)" ঘর রয়েছে। আপনি চাইলে লেটার গ্রেড ড্রপডাউন স্পর্শ না করেই যেকোনো ফ্র্যাকশনাল বা সুনির্দিষ্ট পয়েন্ট (যেমন: ৩.৫৫, ৩.১২, ২.৮৫ ইত্যাদি) সরাসরি লিখে মুহূর্তেই সঠিক সিজিপিএ গণনা করতে পারবেন।
</p>
</div>
<!-- Author Attribution Box -->
<div class="htbd-author-box" style="display: flex; align-items: center; gap: 18px; margin: 40px 0 25px 0; padding: 20px 24px; background: #f8fafc; border: 1px solid #e2e8f0; border-left: 5px solid #1e3a8a; border-radius: 10px; font-family: 'SolaimanLipi', Arial, sans-serif;">
<img alt="ফারুক স্যার (মো. ওমর ফারুক)" class="htbd-author-avatar" height="75" loading="lazy" src="https://cdn.jsdelivr.net/gh/omarfarukitbd-spec/helptrickbdseo@main/assets/images/author/faruk_sir.webp" style="width: 75px !important; height: 75px !important; min-width: 75px !important; max-width: 75px !important; border-radius: 50% !important; object-fit: cover !important; border: 2px solid #2563eb !important; flex-shrink: 0 !important; display: block !important; margin: 0 !important; box-shadow: 0 2px 6px rgba(0,0,0,0.08) !important;" width="75"/>
<div class="htbd-author-info" style="flex: 1 1 auto; min-width: 0;">
<h4 style="margin: 0 0 4px 0; color: #1e3a8a; font-size: 18px; font-weight: 700; line-height: 1.3;">ফারুক স্যার (মো. ওমর ফারুক)</h4>
<div class="htbd-author-meta" style="font-size: 13px; color: #64748b; margin-bottom: 6px; font-weight: 600;">শিক্ষাবিদ ও অ্যাকাডেমিক গবেষক | প্রতিষ্ঠাতা, HelpTrickBD</div>
<p class="htbd-author-bio" style="font-size: 14px; color: #334155; line-height: 1.6; margin: 0;">
      জাতীয় বিশ্ববিদ্যালয় ও উচ্চশিক্ষা অ্যাকাডেমিক পাঠ্যক্রম পর্যালোচনায় দীর্ঘ এক দশকের অভিজ্ঞতাসম্পন্ন একজন অ্যাকাডেমিক মেন্টর ও শিক্ষা গবেষক।
    </p>
</div>
</div>
<!-- ========================================================================== -->
<!-- EMBEDDED JAVASCRIPT LOGIC ENGINE (VANILLA JS, ZERO EXTERNAL DEPENDENCIES)  -->
<!-- ========================================================================== -->
<!-- ========================================================================== -->
<!-- JSON-LD SCHEMA MICRODATA: BlogPosting & FAQPage                            -->
<!-- ========================================================================== -->
        </section>

    </div><!-- .ht-calc-canvas -->
</main><!-- #primary -->

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "BlogPosting",
  "headline": "জাতীয় বিশ্ববিদ্যালয় সিজিপিএ ক্যালকুলেটর ও গ্রেডিং গাইড ২০২৬",
  "description": "জাতীয় বিশ্ববিদ্যালয় অনার্স, ডিগ্রি পাস ও মাস্টার্স শিক্ষার্থীদের জন্য আধুনিক সিজিপিএ ক্যালকুলেটর ২০২৬। ডিপার্টমেন্ট সিলেবাস অটো-লোড, স্মার্ট রেজাল্ট পেস্ট পার্সার, টার্গেট ফার্স্ট ক্লাস প্ল্যানার ও প্রাতিষ্ঠানিক ১-পাতা A4 ট্রান্সক্রিপ্ট প্রিন্ট সুবিধা।",
  "image": "https://cdn.jsdelivr.net/gh/omarfarukitbd-spec/helptrickbdseo@main/assets/images/posts/nu_cgpa_calculator_honours_degree_masters_2026.webp",
  "datePublished": "2026-10-03T14:30:00+06:00",
  "dateModified": "2026-10-03T16:50:00+06:00",
  "author": {
    "@type": "Person",
    "name": "ফারুক স্যার (মো. ওমর ফারুক)",
    "jobTitle": "শিক্ষাবিদ ও অ্যাকাডেমিক গবেষক",
    "url": "<?php echo esc_url(home_url('/about-us/')); ?>"
  },
  "publisher": {
    "@type": "Organization",
    "name": "HelpTrickBD",
    "url": "<?php echo esc_url(home_url('/')); ?>",
    "logo": {
      "@type": "ImageObject",
      "url": "https://cdn.jsdelivr.net/gh/omarfarukitbd-spec/helptrickbdseo@main/assets/images/logo/helptrickbd_logo.webp"
    }
  },
  "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "<?php echo esc_url(get_permalink()); ?>"
  }
}
</script>

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "অনার্স ১ম থেকে ৪র্থ বর্ষ পর্যন্ত মোট ক্রেডিট কত?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "জাতীয় বিশ্ববিদ্যালয়ের চার বছর মেয়াদি অনার্স কোর্সে সাধারণত প্রতি বর্ষে ৩২ ক্রেডিট করে ৪ বছরে সর্বমোট ১২৮ ক্রেডিট সম্পন্ন করতে হয়।"
      }
    },
    {
      "@type": "Question",
      "name": "সিজিপিএ কত পেলে ১ম শ্রেণি বা ফার্স্ট ক্লাস পাওয়া যায়?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "জাতীয় বিশ্ববিদ্যালয়ের নিয়ম অনুযায়ী ফাইনাল সিজিপিএ ৩.০০ (CGPA 3.00) বা তার বেশি অর্জন করলে তা প্রথম শ্রেণি (First Class) হিসেবে গণ্য হয়।"
      }
    },
    {
      "@type": "Question",
      "name": "অনার্স ২য় বর্ষের ইংরেজি আবশ্যিক ফেল করলে কি প্রমোশন আটকে যাবে?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "না, ইংরেজি আবশ্যিক বিষয়ে ফেল করলেও অন্য প্রধান ৩টি বিষয়ে পাস থাকলে ৩য় বর্ষে প্রমোশন দেওয়া হবে। তবে অনার্স শেষ করার পূর্বে অবশ্যই এই নন-ক্রেডিট বিষয়ে পাস করতে হবে।"
      }
    },
    {
      "@type": "Question",
      "name": "ইমপ্রুভমেন্ট পরীক্ষা দিলে সর্বোচ্চ কত গ্রেড পাওয়া যায়?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "সংশোধিত রেগুলেশন ২০২৫ (ধারা ১৪) অনুযায়ী মানোন্নয়নে B+ সর্বোচ্চ সীমা আর প্রযোজ্য নয় — C, C+ বা D গ্রেডের কোর্সে প্রাপ্ত নম্বর অনুযায়ী A+ পর্যন্ত পাওয়া যায়; শুধু F গ্রেডের কোর্সে সর্বোচ্চ গ্রেড A-।"
      }
    },
    {
      "@type": "Question",
      "name": "কোনো বর্ষে এফ (F) গ্রেড থাকলে কি সিজিপিএ হিসাব করা সম্ভব?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "হ্যাঁ, তবে F গ্রেডের গ্রেড পয়েন্ট হলো ০.০০। এটি মোট ক্রেডিটের সাথে যুক্ত হয়ে গড় সিজিপিএ ব্যাপকভাবে হ্রাস করে। পরবর্তী বর্ষে পরীক্ষা দিয়ে F গ্রেড ক্লিয়ার করলে নতুন গ্রেড পয়েন্ট যুক্ত হয়ে সিজিপিএ বৃদ্ধি পাবে।"
      }
    },
    {
      "@type": "Question",
      "name": "লেটার গ্রেড ছাড়া কি সরাসরি দশমিক বা কাস্টম পয়েন্ট দিয়ে সিজিপিএ হিসাব করা যায়?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "হ্যাঁ, হেল্পট্রিকবিডি ক্যালকুলেটরে প্রতিটি বিষয়ের জন্য লেটার গ্রেডের পাশাপাশি সরাসরি পয়েন্ট (GP) ঘর রয়েছে। আপনি যেকোনো ফ্র্যাকশনাল বা সুনির্দিষ্ট পয়েন্ট সরাসরি লিখে সঠিক সিজিপিএ গণনা করতে পারবেন।"
      }
    }
  ]
}
</script>

<?php
get_footer();
